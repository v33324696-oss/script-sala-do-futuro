"""
Zunder — organizador de estudos (clone local, educacional)

Escopo deste projeto:
  - Tarefas:   registrar e acompanhar atividades/prazos das plataformas
  - Redacoes:  editor + checklist de estrutura e competencias (ENEM)
  - Apostilas: anotacoes por materia

O que este projeto NAO faz, de proposito: nao acessa a Sala do Futuro,
nao usa a senha da Secretaria e nao responde nem envia atividades
avaliativas em nome do aluno. A senha pedida no login e uma senha
LOCAL deste aplicativo, guardada com hash.
"""

import os
import re
import json
import sqlite3
import urllib.request
import urllib.error
from datetime import datetime, date, timedelta

from flask import (
    Flask, g, jsonify, render_template, request, session, redirect, url_for
)
from werkzeug.security import generate_password_hash, check_password_hash

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "zunder.db")
SECRET_KEY = os.environ.get("ZUNDER_SECRET", "zunder-local-dev-key")

app = Flask(__name__)
app.secret_key = SECRET_KEY
app.config["JSON_SORT_KEYS"] = False

# Sessao de navegador: some quando a aba fecha (nao eh "manter conectado").
app.config.update(
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
)

TERMS_VERSION = "1.0"

# Servidor de captura (sala-playwright/server.js)
NODE = os.environ.get("ZUNDER_CAPTURE", "http://127.0.0.1:8765")

PLATFORMS = [
    "TarefaSP", "Redação Paulista", "LeiaSP+", "Expansão Noturna",
    "Alura", "Open English", "Educação Profissional", "Matific",
    "Prepara-SP", "Khan Academy", "Matemática EM", "Speak",
]

SUBJECTS = [
    "Português", "Matemática", "História", "Geografia", "Biologia",
    "Física", "Química", "Filosofia", "Sociologia", "Inglês",
    "Artes", "Educação Física", "Tecnologia", "Outro",
]


# ---------------------------------------------------------------- banco

def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


@app.teardown_appcontext
def close_db(_exc):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    db = sqlite3.connect(DB_PATH)
    db.executescript(
        """
        CREATE TABLE IF NOT EXISTS users (
            id             INTEGER PRIMARY KEY AUTOINCREMENT,
            ra             TEXT NOT NULL,
            digito         TEXT NOT NULL DEFAULT '',
            uf             TEXT NOT NULL DEFAULT 'SP',
            password_hash  TEXT NOT NULL,
            created_at     TEXT NOT NULL,
            last_login     TEXT,
            terms_version  TEXT,
            terms_accepted TEXT
        );
        CREATE UNIQUE INDEX IF NOT EXISTS idx_users_ra
            ON users (ra, digito, uf);

        CREATE TABLE IF NOT EXISTS tasks (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            title       TEXT NOT NULL,
            platform    TEXT NOT NULL DEFAULT 'TarefaSP',
            subject     TEXT NOT NULL DEFAULT 'Outro',
            description TEXT NOT NULL DEFAULT '',
            due_date    TEXT,
            priority    INTEGER NOT NULL DEFAULT 2,   -- 1 alta, 2 media, 3 baixa
            status      TEXT NOT NULL DEFAULT 'pending',
            grade       TEXT,
            created_at  TEXT NOT NULL,
            done_at     TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_tasks_user ON tasks (user_id);

        CREATE TABLE IF NOT EXISTS essays (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            theme      TEXT NOT NULL DEFAULT '',
            content    TEXT NOT NULL DEFAULT '',
            status     TEXT NOT NULL DEFAULT 'draft',
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_essays_user ON essays (user_id);

        CREATE TABLE IF NOT EXISTS notes (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            subject    TEXT NOT NULL DEFAULT 'Outro',
            title      TEXT NOT NULL,
            content    TEXT NOT NULL DEFAULT '',
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_notes_user ON notes (user_id);

        CREATE TABLE IF NOT EXISTS settings (
            user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            key     TEXT NOT NULL,
            value   TEXT NOT NULL,
            PRIMARY KEY (user_id, key)
        );
        """
    )
    db.commit()
    db.close()


def now_iso():
    return datetime.now().isoformat(timespec="seconds")


def current_user():
    uid = session.get("uid")
    if not uid:
        return None
    return get_db().execute(
        "SELECT id, ra, digito, uf, created_at, terms_accepted FROM users WHERE id = ?",
        (uid,),
    ).fetchone()


def require_user():
    u = current_user()
    if not u:
        return None
    return u


# ---------------------------------------------------------------- ajuda

def row_to_task(r):
    t = dict(r)
    t["overdue"] = False
    if t.get("due_date") and t["status"] != "done":
        try:
            due = date.fromisoformat(t["due_date"])
            t["overdue"] = due < date.today()
            t["days_left"] = (due - date.today()).days
        except ValueError:
            t["days_left"] = None
    else:
        t["days_left"] = None
    return t


# ---------------------------------------------------------------- rotas

@app.get("/")
def index():
    if current_user():
        return redirect(url_for("painel"))
    return render_template("login.html", platforms=PLATFORMS, terms_version=TERMS_VERSION)


@app.get("/app")
def painel():
    if not current_user():
        return redirect(url_for("index"))
    return render_template("app.html",
                           platforms=PLATFORMS,
                           subjects=SUBJECTS,
                           terms_version=TERMS_VERSION)


# --- autenticacao -----------------------------------------------------

@app.post("/api/login")
def api_login():
    data = request.get_json(silent=True) or {}
    ra = re.sub(r"\D", "", str(data.get("ra", "")))
    digito = re.sub(r"\D", "", str(data.get("digito", "")))[:2]
    uf = str(data.get("uf", "SP")).upper()[:2]
    senha = str(data.get("password", ""))

    if len(ra) < 4:
        return jsonify(ok=False, error="Informe um RA válido (ao menos 4 números)."), 400
    if len(uf) != 2:
        return jsonify(ok=False, error="UF inválida."), 400
    if len(senha) < 4:
        return jsonify(ok=False, error="A senha local precisa ter ao menos 4 caracteres."), 400

    db = get_db()
    user = db.execute(
        "SELECT * FROM users WHERE ra = ? AND digito = ? AND uf = ?", (ra, digito, uf)
    ).fetchone()

    if user is None:
        # Primeiro acesso deste RA: cria a conta local.
        cur = db.execute(
            "INSERT INTO users (ra, digito, uf, password_hash, created_at,"
            " last_login, terms_version, terms_accepted)"
            " VALUES (?,?,?,?,?,?,?,?)",
            (ra, digito, uf, generate_password_hash(senha), now_iso(),
             now_iso(), TERMS_VERSION, now_iso()),
        )
        db.commit()
        uid = cur.lastrowid
    else:
        if not check_password_hash(user["password_hash"], senha):
            return jsonify(ok=False, error="Senha incorreta para este RA."), 401
        db.execute(
            "UPDATE users SET last_login = ? WHERE id = ?", (now_iso(), user["id"])
        )
        db.commit()
        uid = user["id"]

    session.clear()
    session["uid"] = uid
    session["ra"] = f"{ra}-{digito}" if digito else ra
    return jsonify(ok=True, redirect="/app")


@app.post("/api/logout")
def api_logout():
    session.clear()
    return jsonify(ok=True, redirect="/")


@app.get("/api/me")
def api_me():
    u = require_user()
    if not u:
        return jsonify(ok=False, error="Não autenticado."), 401
    return jsonify(ok=True, user={
        "ra": u["ra"], "digito": u["digito"], "uf": u["uf"],
        "since": u["created_at"],
    })


@app.get("/api/saved-accounts")
def api_saved_accounts():
    """Contas criadas nesta instância local (só o RA — nunca a senha)."""
    rows = get_db().execute(
        "SELECT ra, digito, uf, last_login FROM users ORDER BY last_login DESC LIMIT 20"
    ).fetchall()
    return jsonify(ok=True, accounts=[dict(r) for r in rows])


# --- tarefas ----------------------------------------------------------

@app.get("/api/tasks")
def api_tasks():
    u = require_user()
    if not u:
        return jsonify(ok=False, error="Não autenticado."), 401
    rows = get_db().execute(
        "SELECT * FROM tasks WHERE user_id = ? ORDER BY "
        "CASE status WHEN 'pending' THEN 0 ELSE 1 END, "
        "COALESCE(due_date, '9999-12-31'), priority, id DESC",
        (u["id"],),
    ).fetchall()
    return jsonify(ok=True, tasks=[row_to_task(r) for r in rows])


@app.post("/api/tasks")
def api_task_create():
    u = require_user()
    if not u:
        return jsonify(ok=False, error="Não autenticado."), 401
    d = request.get_json(silent=True) or {}
    title = str(d.get("title", "")).strip()
    if not title:
        return jsonify(ok=False, error="Dê um título à tarefa."), 400
    due = str(d.get("due_date", "")).strip() or None
    if due:
        try:
            date.fromisoformat(due)
        except ValueError:
            return jsonify(ok=False, error="Data de entrega inválida."), 400
    cur = get_db().execute(
        "INSERT INTO tasks (user_id, title, platform, subject, description,"
        " due_date, priority, status, created_at)"
        " VALUES (?,?,?,?,?,?,?,?,?)",
        (u["id"], title[:180],
         d.get("platform") or "TarefaSP",
         d.get("subject") or "Outro",
         str(d.get("description", ""))[:2000],
         due, int(d.get("priority") or 2), "pending", now_iso()),
    )
    get_db().commit()
    return jsonify(ok=True, id=cur.lastrowid)


@app.patch("/api/tasks/<int:tid>")
def api_task_update(tid):
    u = require_user()
    if not u:
        return jsonify(ok=False, error="Não autenticado."), 401
    d = request.get_json(silent=True) or {}
    db = get_db()
    task = db.execute(
        "SELECT * FROM tasks WHERE id = ? AND user_id = ?", (tid, u["id"])
    ).fetchone()
    if not task:
        return jsonify(ok=False, error="Tarefa não encontrada."), 404

    fields = {}
    for key in ("title", "platform", "subject", "description", "due_date",
                "grade"):
        if key in d:
            fields[key] = d[key]
    if "priority" in d:
        fields["priority"] = int(d["priority"])
    if "status" in d:
        fields["status"] = "done" if d["status"] == "done" else "pending"
        fields["done_at"] = now_iso() if fields["status"] == "done" else None

    if not fields:
        return jsonify(ok=False, error="Nada para atualizar."), 400

    sets = ", ".join(f"{k} = ?" for k in fields)
    db.execute(f"UPDATE tasks SET {sets} WHERE id = ?",
               (*fields.values(), tid))
    db.commit()
    return jsonify(ok=True)


@app.delete("/api/tasks/<int:tid>")
def api_task_delete(tid):
    u = require_user()
    if not u:
        return jsonify(ok=False, error="Não autenticado."), 401
    db = get_db()
    db.execute("DELETE FROM tasks WHERE id = ? AND user_id = ?", (tid, u["id"]))
    db.commit()
    return jsonify(ok=True)


@app.get("/api/stats")
def api_stats():
    u = require_user()
    if not u:
        return jsonify(ok=False, error="Não autenticado."), 401
    db = get_db()
    rows = db.execute("SELECT * FROM tasks WHERE user_id = ?", (u["id"],)).fetchall()
    today = date.today()
    total = len(rows)
    done = sum(1 for r in rows if r["status"] == "done")
    pending = total - done
    overdue = sum(
        1 for r in rows
        if r["status"] != "done" and r["due_date"]
        and date.fromisoformat(r["due_date"]) < today
    )
    due_soon = sum(
        1 for r in rows
        if r["status"] != "done" and r["due_date"]
        and today <= date.fromisoformat(r["due_date"]) <= today + timedelta(days=3)
    )
    by_platform = {}
    for r in rows:
        p = r["platform"]
        s = by_platform.setdefault(p, {"total": 0, "done": 0})
        s["total"] += 1
        s["done"] += 1 if r["status"] == "done" else 0

    # conclusoes dos ultimos 14 dias (grafico)
    series = []
    for i in range(13, -1, -1):
        day = today - timedelta(days=i)
        series.append({
            "day": day.isoformat(),
            "count": sum(1 for r in rows
                         if r["done_at"] and r["done_at"][:10] == day.isoformat()),
        })

    return jsonify(ok=True, stats={
        "total": total, "done": done, "pending": pending,
        "overdue": overdue, "due_soon": due_soon,
        "rate": round(done / total * 100) if total else 0,
        "by_platform": by_platform, "series": series,
    })


# --- redacoes ---------------------------------------------------------

@app.get("/api/essays")
def api_essays():
    u = require_user()
    if not u:
        return jsonify(ok=False, error="Não autenticado."), 401
    rows = get_db().execute(
        "SELECT id, theme, status, created_at, updated_at,"
        " LENGTH(content) AS size FROM essays WHERE user_id = ?"
        " ORDER BY updated_at DESC", (u["id"],)
    ).fetchall()
    return jsonify(ok=True, essays=[dict(r) for r in rows])


@app.get("/api/essays/<int:eid>")
def api_essay_get(eid):
    u = require_user()
    if not u:
        return jsonify(ok=False, error="Não autenticado."), 401
    r = get_db().execute(
        "SELECT * FROM essays WHERE id = ? AND user_id = ?", (eid, u["id"])
    ).fetchone()
    if not r:
        return jsonify(ok=False, error="Redação não encontrada."), 404
    return jsonify(ok=True, essay=dict(r))


@app.post("/api/essays")
def api_essay_create():
    u = require_user()
    if not u:
        return jsonify(ok=False, error="Não autenticado."), 401
    d = request.get_json(silent=True) or {}
    cur = get_db().execute(
        "INSERT INTO essays (user_id, theme, content, status, created_at, updated_at)"
        " VALUES (?,?,?,?,?,?)",
        (u["id"], str(d.get("theme", ""))[:300], "", "draft", now_iso(), now_iso()),
    )
    get_db().commit()
    return jsonify(ok=True, id=cur.lastrowid)


@app.put("/api/essays/<int:eid>")
def api_essay_save(eid):
    u = require_user()
    if not u:
        return jsonify(ok=False, error="Não autenticado."), 401
    d = request.get_json(silent=True) or {}
    db = get_db()
    r = db.execute(
        "SELECT id FROM essays WHERE id = ? AND user_id = ?", (eid, u["id"])
    ).fetchone()
    if not r:
        return jsonify(ok=False, error="Redação não encontrada."), 404
    db.execute(
        "UPDATE essays SET theme = ?, content = ?, status = ?, updated_at = ? WHERE id = ?",
        (str(d.get("theme", ""))[:300], str(d.get("content", "")),
         d.get("status") or "draft", now_iso(), eid),
    )
    db.commit()
    return jsonify(ok=True)


@app.delete("/api/essays/<int:eid>")
def api_essay_delete(eid):
    u = require_user()
    if not u:
        return jsonify(ok=False, error="Não autenticado."), 401
    db = get_db()
    db.execute("DELETE FROM essays WHERE id = ? AND user_id = ?", (eid, u["id"]))
    db.commit()
    return jsonify(ok=True)


# --- apostilas --------------------------------------------------------

@app.get("/api/notes")
def api_notes():
    u = require_user()
    if not u:
        return jsonify(ok=False, error="Não autenticado."), 401
    rows = get_db().execute(
        "SELECT * FROM notes WHERE user_id = ? ORDER BY updated_at DESC", (u["id"],)
    ).fetchall()
    return jsonify(ok=True, notes=[dict(r) for r in rows])


@app.post("/api/notes")
def api_note_create():
    u = require_user()
    if not u:
        return jsonify(ok=False, error="Não autenticado."), 401
    d = request.get_json(silent=True) or {}
    title = str(d.get("title", "")).strip() or "Sem título"
    cur = get_db().execute(
        "INSERT INTO notes (user_id, subject, title, content, created_at, updated_at)"
        " VALUES (?,?,?,?,?,?)",
        (u["id"], d.get("subject") or "Outro", title[:180], "", now_iso(), now_iso()),
    )
    get_db().commit()
    return jsonify(ok=True, id=cur.lastrowid)


@app.put("/api/notes/<int:nid>")
def api_note_save(nid):
    u = require_user()
    if not u:
        return jsonify(ok=False, error="Não autenticado."), 401
    d = request.get_json(silent=True) or {}
    db = get_db()
    r = db.execute(
        "SELECT id FROM notes WHERE id = ? AND user_id = ?", (nid, u["id"])
    ).fetchone()
    if not r:
        return jsonify(ok=False, error="Anotação não encontrada."), 404
    db.execute(
        "UPDATE notes SET subject = ?, title = ?, content = ?, updated_at = ? WHERE id = ?",
        (d.get("subject") or "Outro", str(d.get("title", ""))[:180],
         str(d.get("content", "")), now_iso(), nid),
    )
    db.commit()
    return jsonify(ok=True)


@app.delete("/api/notes/<int:nid>")
def api_note_delete(nid):
    u = require_user()
    if not u:
        return jsonify(ok=False, error="Não autenticado."), 401
    db = get_db()
    db.execute("DELETE FROM notes WHERE id = ? AND user_id = ?", (nid, u["id"]))
    db.commit()
    return jsonify(ok=True)


# ---------------------------------------------------------------- sala do futuro
#
# Ponte para o servidor de captura (sala-playwright/server.js).
# O login e feito pela propria pessoa, no navegador aberto pelo Playwright.
# Nenhuma senha passa por aqui. Este modulo apenas LE o DOM.

def node_call(path, method="GET", payload=None):
    data = json.dumps(payload).encode("utf-8") if payload is not None else None
    req = urllib.request.Request(
        NODE + path, data=data, method=method,
        headers={"Content-Type": "application/json"},
    )
    try:
        with urllib.request.urlopen(req, timeout=90) as r:
            raw = r.read().decode("utf-8", "replace")
            return json.loads(raw) if raw else {"ok": True}, r.status
    except urllib.error.HTTPError as e:
        raw = e.read().decode("utf-8", "replace")
        try:
            return json.loads(raw), e.code
        except ValueError:
            return {"ok": False, "error": raw or str(e)}, e.code
    except Exception as e:
        return {
            "ok": False,
            "offline": True,
            "error": "Servidor de captura indisponível. Inicie com: cd sala-playwright && npm start",
            "detail": str(e),
        }, 503


def get_setting(uid, key, default=None):
    r = get_db().execute(
        "SELECT value FROM settings WHERE user_id = ? AND key = ?", (uid, key)
    ).fetchone()
    return r["value"] if r else default


def set_setting(uid, key, value):
    db = get_db()
    db.execute(
        "INSERT INTO settings (user_id, key, value) VALUES (?,?,?) "
        "ON CONFLICT(user_id, key) DO UPDATE SET value = excluded.value",
        (uid, key, value),
    )
    db.commit()


@app.get("/api/sala/status")
def api_sala_status():
    if not require_user():
        return jsonify(ok=False, error="Não autenticado."), 401
    body, code = node_call("/status")
    body["selector"] = get_setting(current_user()["id"], "selector", "")
    body["platform"] = get_setting(current_user()["id"], "platform", "")
    return jsonify(body), code


@app.post("/api/sala/open")
def api_sala_open():
    if not require_user():
        return jsonify(ok=False, error="Não autenticado."), 401
    body, code = node_call("/open", "POST", (request.get_json(silent=True) or {}))
    return jsonify(body), code


@app.post("/api/sala/capture")
def api_sala_capture():
    if not require_user():
        return jsonify(ok=False, error="Não autenticado."), 401
    dados = request.get_json(silent=True) or {}
    payload = {}
    if dados.get("use_saved") and not dados.get("selector"):
        payload["selector"] = get_setting(current_user()["id"], "selector", "") or None
    elif dados.get("selector"):
        payload["selector"] = dados["selector"]
    if dados.get("platform"):
        payload["platform"] = dados["platform"]
    body, code = node_call("/capture", "POST", payload)
    return jsonify(body), code


@app.post("/api/sala/close")
def api_sala_close():
    if not require_user():
        return jsonify(ok=False, error="Não autenticado."), 401
    body, code = node_call("/close", "POST", {})
    return jsonify(body), code


@app.post("/api/sala/selector")
def api_sala_selector():
    u = require_user()
    if not u:
        return jsonify(ok=False, error="Não autenticado."), 401
    d = request.get_json(silent=True) or {}
    if "selector" in d:
        set_setting(u["id"], "selector", str(d["selector"] or ""))
    if "platform" in d:
        set_setting(u["id"], "platform", str(d["platform"] or ""))
    return jsonify(ok=True)


@app.post("/api/sala/import")
def api_sala_import():
    """Salva os itens capturados como tarefas, sem duplicar."""
    u = require_user()
    if not u:
        return jsonify(ok=False, error="Não autenticado."), 401
    d = request.get_json(silent=True) or {}
    items = d.get("items") or []
    only_pending = bool(d.get("only_pending", True))
    platform = d.get("platform") or "TarefaSP"

    db = get_db()
    existentes = {
        (r["title"].strip().lower(), r["due_date"], r["platform"])
        for r in db.execute("SELECT title, due_date, platform FROM tasks WHERE user_id = ?", (u["id"],))
    }

    criadas, ignoradas = 0, 0
    for it in items:
        titulo = str(it.get("title", "")).strip()
        if not titulo or len(titulo) < 3:
            continue
        status_txt = str(it.get("status") or "unknown")
        if only_pending and status_txt == "done":
            ignoradas += 1
            continue
        due = it.get("due_date") or None
        plat = it.get("platform") or platform
        chave = (titulo.lower(), due, plat)
        if chave in existentes:
            ignoradas += 1
            continue
        db.execute(
            "INSERT INTO tasks (user_id, title, platform, subject, description,"
            " due_date, priority, status, created_at)"
            " VALUES (?,?,?,?,?,?,?,?,?)",
            (u["id"], titulo[:180], plat, it.get("subject") or "Outro",
             str(it.get("raw") or "")[:2000], due, 2, "pending", now_iso()),
        )
        existentes.add(chave)
        criadas += 1

    db.commit()
    return jsonify(ok=True, criadas=criadas, ignoradas=ignoradas)


@app.get("/api/pending")
def api_pending():
    """Agrupa as tarefas pendentes por plataforma e por urgência."""
    u = require_user()
    if not u:
        return jsonify(ok=False, error="Não autenticado."), 401
    db = get_db()
    hoje = date.today()
    rows = [row_to_task(r) for r in db.execute(
        "SELECT * FROM tasks WHERE user_id = ? AND status != 'done' ORDER BY "
        "COALESCE(due_date,'9999-12-31'), priority", (u["id"],)
    ).fetchall()]

    por_plataforma = {}
    for t in rows:
        p = t["platform"]
        s = por_plataforma.setdefault(p, {"total": 0, "atrasadas": 0, "semana": 0})
        s["total"] += 1
        if t["overdue"]:
            s["atrasadas"] += 1
        elif t["days_left"] is not None and t["days_left"] <= 7:
            s["semana"] += 1

    faixas = {"atrasadas": [], "hoje": [], "3dias": [], "7dias": [], "depois": [], "sem_prazo": []}
    for t in rows:
        d = t["days_left"]
        if t["overdue"]:
            faixas["atrasadas"].append(t)
        elif d is None:
            faixas["sem_prazo"].append(t)
        elif d == 0:
            faixas["hoje"].append(t)
        elif d <= 3:
            faixas["3dias"].append(t)
        elif d <= 7:
            faixas["7dias"].append(t)
        else:
            faixas["depois"].append(t)

    return jsonify(ok=True, pending={
        "total": len(rows),
        "atrasadas": len(faixas["atrasadas"]),
        "hoje": len(faixas["hoje"]),
        "semana": len(faixas["3dias"]) + len(faixas["7dias"]),
        "por_plataforma": por_plataforma,
        "faixas": {k: [row_to_task(x) for x in v] for k, v in faixas.items()},
        "gerado_em": datetime.now().strftime("%d/%m/%Y %H:%M"),
    })


# ---------------------------------------------------------------- init

init_db()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=False)
