# Zunder — organizador de estudos (clone local)

Réplica da identidade visual do [zunder.lat](https://zunder.lat/), com os três
módulos que o lema do site anuncia — **tarefas, redações e apostilas** —
implementados de forma funcional, mais um módulo de **captura somente-leitura
da Sala do Futuro**.

## Subir o projeto

São dois processos. O Zunder (Flask) e o servidor de captura (Playwright).

```bash
# 1. aplicativo principal  ->  http://localhost:5000
cd zunder
pip install flask
python3 app.py

# 2. servidor de captura   ->  http://localhost:8765
cd zunder/sala-playwright
./start.sh          # ou: npm install && npx playwright install chromium && npm start
```

O Zunder funciona sem o servidor de captura — o módulo **Sala do Futuro**
apenas avisa que ele está offline.

## Módulos

### Pendentes (tela inicial após login)
Mostra exatamente **quantas tarefas estão pendentes em cada plataforma**
(`TarefaSP — X pendentes`), com atrasadas separadas e quadro por urgência:
atrasadas · vence hoje · próx. 3 dias · próx. 7 dias · mais de 7 dias · sem prazo.

### Tarefas
Cadastro com título, plataforma (12 opções), matéria, prazo, prioridade e nota.
Edição, exclusão, conclusão com um clique, filtros e painel com taxa de
conclusão e gráfico de 14 dias.

### Redações
Editor com contagem ao vivo e faixa do ENEM, checklist de estrutura,
**detector dos 5 elementos da proposta de intervenção**, autoavaliação pelas
5 competências e acervo de 22 repertórios socioculturais.

### Apostilas
Cadernos por matéria com busca e editor Markdown com preview.

### Sala do Futuro (captura somente-leitura)
Abre um Chromium controlado pelo Playwright. **Você** faz login e navega;
a ferramenta lê a página e devolve as tarefas estruturadas para importar.

Veja [`sala-playwright/README.md`](sala-playwright/README.md) para os detalhes.

## Sobre o HTML da Sala do Futuro

Não existe API pública da Sala do Futuro — o acesso é só por RA e senha.
Por isso o módulo não embute seletores chutados: o `extract.js` **descobre** a
estrutura em tempo real, procurando conjuntos de elementos repetidos e
pontuando cada um (quantidade, tamanho do texto, presença de data, de palavras
de status e de nome de plataforma). Ele ranqueia os candidatos e você escolhe
o certo uma vez; o seletor fica salvo.

Validado contra o site real: o portal é um app React/MUI, e o extrator
encontrou 9 candidatos sem quebrar. Como as classes do MUI são geradas
(`css-1h8mkiv`) e mudam a cada deploy, a redescoberta automática é o que faz a
captura continuar funcionando.

## O que este projeto **não** faz — de propósito

O site original é um automatizador: recebe o RA e a senha da Sala do Futuro e
**responde e envia atividades avaliativas em nome do aluno**. Esta réplica não
faz isso, e não é limitação técnica:

- ❌ não preenche formulário, não clica em botão, não envia resposta
- ❌ não coleta a senha da Secretaria — a senha do login é **local**, guardada
  como hash PBKDF2, e a senha da Sala do Futuro é digitada por você, no portal
- ❌ não automatiza tarefa nenhuma em plataforma de terceiros
- ❌ não garante nota, aprovação ou conclusão de atividade

O módulo de captura é somente-leitura por construção: não existe uma única
chamada a `page.fill()`, `page.click()` ou `page.type()` no `server.js`.

O que ele faz é o que ajuda de verdade: organizar o que você precisa entregar,
mostrar o que está pendente e apoiar a sua escrita. A autoria do que você
entrega continua sendo sua.

## Estrutura

```
zunder/
├── app.py                      # Flask + SQLite
├── zunder.db                   # gerado na 1ª execução
├── templates/
│   ├── login.html              # clone visual da tela de entrada
│   └── app.html                # painel (5 módulos)
├── static/
│   ├── css/style.css           # CSS do site original + módulos
│   ├── js/login.js             # splash, UF, verificação, termos, contas salvas
│   ├── js/app.js               # pendentes, tarefas, redações, apostilas, sala
│   └── images/                 # lockup, símbolo, favicon
└── sala-playwright/
    ├── server.js               # servidor HTTP :8765 — controle do navegador
    ├── extract.js              # extrator adaptativo
    ├── start.sh
    └── package.json
```

## API do Zunder

| Método | Rota | Uso |
|---|---|---|
| POST | `/api/login` | entra (cria conta local no 1º acesso do RA) |
| POST | `/api/logout` · GET `/api/me` | sessão |
| GET | `/api/pending` | pendentes por plataforma e por urgência |
| GET/POST | `/api/tasks` · PATCH/DELETE `/api/tasks/<id>` | tarefas |
| GET | `/api/stats` | números do painel |
| GET/POST | `/api/essays` · GET/PUT/DELETE `/api/essays/<id>` | redações |
| GET/POST | `/api/notes` · PUT/DELETE `/api/notes/<id>` | apostilas |
| GET/POST | `/api/sala/open` · `/api/sala/capture` · `/api/sala/close` | ponte para a captura |
| POST | `/api/sala/import` · `/api/sala/selector` | importar itens · salvar seletor |

## Segurança

- Senha local com hash PBKDF2 (`werkzeug.security`), nunca em texto
- Sessão em cookie `HttpOnly` + `SameSite=Lax`
- Consultas parametrizadas e filtradas por `user_id`
- Captura restrita a `educacao.sp.gov.br` — qualquer outro domínio é recusado
- HTML capturado é higienizado: remove `<script>`, `<iframe>`, `<object>`,
  `<embed>`, `<noscript>`, `<style>`, `<svg>`, handlers `on*`, valores de
  formulário e URLs `javascript:`
- Perfil do navegador é temporário e apagado ao fechar; nada de cookie persistente
- Nenhuma dependência externa em runtime: sem CDN e sem script de terceiros
