/* Zunder — tela de entrada */
(function () {
  'use strict';

  var $ = function (id) { return document.getElementById(id); };

  /* ---------------- splash / revelação do logo ---------------- */
  window.addEventListener('load', function () {
    var splash = $('splashLogo');
    var logo = $('logoCmsp');
    setTimeout(function () {
      if (splash) { splash.style.transition = 'opacity .45s ease'; splash.style.opacity = '0'; }
      setTimeout(function () {
        document.body.classList.remove('splash-active');
        if (logo) logo.classList.add('is-revealed');
      }, 380);
    }, 700);
  });

  /* ---------------- seletor de UF ---------------- */
  var ufTrigger = $('ufTrigger');
  var ufDropdown = $('ufDropdown');
  var ufInput = $('uf');

  if (ufTrigger && ufDropdown) {
    ufTrigger.addEventListener('click', function (e) {
      e.preventDefault();
      var open = ufDropdown.hidden;
      ufDropdown.hidden = !open;
      ufTrigger.setAttribute('aria-expanded', String(open));
      if (open) {
        var sel = ufDropdown.querySelector('button.selected');
        if (sel) sel.scrollIntoView({ block: 'nearest' });
      }
    });

    ufDropdown.addEventListener('click', function (e) {
      var btn = e.target.closest('button[data-uf]');
      if (!btn) return;
      ufDropdown.querySelectorAll('button').forEach(function (b) { b.classList.remove('selected'); });
      btn.classList.add('selected');
      ufTrigger.textContent = btn.dataset.uf;
      ufInput.value = btn.dataset.uf;
      ufDropdown.hidden = true;
      ufTrigger.setAttribute('aria-expanded', 'false');
    });

    document.addEventListener('click', function (e) {
      if (!e.target.closest('#ufSelect')) {
        ufDropdown.hidden = true;
        ufTrigger.setAttribute('aria-expanded', 'false');
      }
    });
  }

  /* ---------------- mostrar/ocultar senha ---------------- */
  var senha = $('senha');
  var senhaToggle = $('senhaToggle');
  if (senha && senhaToggle) {
    senhaToggle.addEventListener('click', function () {
      var showing = senha.type === 'text';
      senha.type = showing ? 'password' : 'text';
      senhaToggle.setAttribute('aria-label', showing ? 'Mostrar senha' : 'Ocultar senha');
    });
  }

  /* ---------------- verificação (desafio simples, local) ----------------
     Não é o Cloudflare Turnstile. É um desafio aritmético local, apenas
     para o gesto de "confirmar que é humano" existir de forma honesta.  */
  var ts = { ok: false };
  var tsWidget = $('tsWidget');
  var tsCheckbox = $('tsCheckbox');
  var tsChallenge = $('tsChallenge');
  var tsQuestion = $('tsQuestion');
  var tsAnswer = $('tsAnswer');
  var a = 0, b = 0;

  function newChallenge() {
    a = 2 + Math.floor(Math.random() * 8);
    b = 3 + Math.floor(Math.random() * 7);
    if (tsQuestion) tsQuestion.textContent = 'Quanto é ' + a + ' + ' + b + '?';
    if (tsAnswer) { tsAnswer.value = ''; tsAnswer.focus(); }
  }

  function setTsState(cls) {
    tsWidget.classList.remove('is-checking', 'is-ok', 'is-error');
    if (cls) tsWidget.classList.add(cls);
  }

  if (tsCheckbox && tsWidget) {
    tsCheckbox.addEventListener('change', function () {
      if (!tsCheckbox.checked) {
        ts.ok = false;
        tsChallenge.hidden = true;
        setTsState(null);
        updateBtn();
        return;
      }
      setTsState('is-checking');
      setTimeout(function () {
        newChallenge();
        tsChallenge.hidden = false;
        setTsState(null);
      }, 700);
    });
  }

  function solve() {
    if (!tsAnswer) return;
    if (tsAnswer.value.trim() === String(a + b)) {
      ts.ok = true;
      tsChallenge.hidden = true;
      setTsState('is-ok');
      toast('Verificação concluída.', 'ok');
    } else {
      setTsState('is-error');
      tsAnswer.value = '';
      newChallenge();
      setTimeout(function () { if (!ts.ok) setTsState(null); }, 900);
    }
    updateBtn();
  }

  var tsOk = $('tsOk');
  if (tsOk) tsOk.addEventListener('click', solve);
  if (tsAnswer) tsAnswer.addEventListener('keydown', function (e) {
    if (e.key === 'Enter') { e.preventDefault(); solve(); }
  });

  /* ---------------- termos ---------------- */
  var termosInput = $('termos');
  var termosCheck = $('termosCheck');
  var termosModal = $('termosModal');
  var btnLogin = $('btnLogin');

  function updateBtn() {
    if (!btnLogin) return;
    btnLogin.disabled = !(ts.ok && termosInput && termosInput.checked);
  }

  if (termosInput) termosInput.addEventListener('change', function () {
    termosCheck.classList.remove('termos-faltando');
    updateBtn();
  });

  document.querySelectorAll('[data-termos]').forEach(function (btn) {
    btn.addEventListener('click', function (e) {
      e.preventDefault();
      openTermos(btn.dataset.termos);
    });
  });

  function openTermos(tab) {
    termosModal.hidden = false;
    switchTab(tab || 'termos');
  }

  function switchTab(tab) {
    document.querySelectorAll('.termos-tab').forEach(function (t) {
      t.classList.toggle('is-active', t.dataset.tab === tab);
    });
    var isT = tab === 'termos';
    $('corpoTermos').hidden = !isT;
    $('corpoPrivacidade').hidden = isT;
    $('termosTitle').textContent = isT ? 'Termos de Uso' : 'Política de Privacidade';
    $('corpoTermos').scrollTop = 0;
    $('corpoPrivacidade').scrollTop = 0;
  }

  document.querySelectorAll('.termos-tab').forEach(function (t) {
    t.addEventListener('click', function () { switchTab(t.dataset.tab); });
  });

  document.querySelectorAll('[data-close-termos]').forEach(function (el) {
    el.addEventListener('click', function () { termosModal.hidden = true; });
  });

  var btnAceitar = $('btnAceitarTermos');
  if (btnAceitar) btnAceitar.addEventListener('click', function () {
    termosInput.checked = true;
    termosCheck.classList.remove('termos-faltando');
    termosModal.hidden = true;
    updateBtn();
  });

  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') { termosModal.hidden = true; $('savedModal').hidden = true; }
  });

  /* ---------------- contas salvas ---------------- */
  var savedModal = $('savedModal');
  var btnSaved = $('btnSavedAccounts');
  if (btnSaved) btnSaved.addEventListener('click', function () {
    savedModal.hidden = false;
    fetch('/api/saved-accounts').then(function (r) { return r.json(); })
      .then(function (data) { renderSaved(data.accounts || []); })
      .catch(function () { renderSaved([]); });
  });

  document.querySelectorAll('[data-close-saved]').forEach(function (el) {
    el.addEventListener('click', function () { savedModal.hidden = true; });
  });

  function renderSaved(accounts) {
    var list = $('savedList');
    if (!accounts.length) {
      list.innerHTML = '<div class="accounts-empty">Nenhuma conta nesta instância ainda.<br>Entre uma vez e ela aparece aqui.</div>';
      return;
    }
    list.innerHTML = accounts.map(function (acc) {
      var ra = acc.ra + (acc.digito ? '-' + acc.digito : '') + '/' + acc.uf;
      return '<div class="saved-account-item">' +
        '<div class="saved-account-avatar"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/></svg></div>' +
        '<div class="saved-account-info"><div class="saved-account-ra">' + ra + '</div>' +
        '<div class="saved-account-password">••••••••</div></div>' +
        '<div class="saved-account-actions">' +
        '<button type="button" class="saved-account-login" data-ra="' + acc.ra + '" data-digito="' + (acc.digito || '') + '" data-uf="' + acc.uf + '">Usar</button>' +
        '</div></div>';
    }).join('');

    list.querySelectorAll('.saved-account-login').forEach(function (btn) {
      btn.addEventListener('click', function () {
        $('ra').value = btn.dataset.ra;
        $('digito').value = btn.dataset.digito;
        var uf = btn.dataset.uf;
        ufInput.value = uf;
        ufTrigger.textContent = uf;
        ufDropdown.querySelectorAll('button').forEach(function (x) {
          x.classList.toggle('selected', x.dataset.uf === uf);
        });
        savedModal.hidden = true;
        senha.focus();
      });
    });
  }

  /* ---------------- submit ---------------- */
  var form = $('loginForm');
  var errBox = $('loginError');

  function showErr(msg) {
    errBox.textContent = msg;
    errBox.classList.add('visible');
  }

  form.addEventListener('submit', function (e) {
    e.preventDefault();
    errBox.classList.remove('visible');

    var ra = $('ra').value.replace(/\D/g, '');
    if (ra.length < 4) { showErr('Informe um RA válido.'); return; }
    if (!ts.ok) {
      tsCheckbox.checked = false;
      setTsState(null);
      tsChallenge.hidden = true;
      showErr('Conclua a verificação antes de entrar.');
      return;
    }
    if (!termosInput.checked) {
      termosCheck.classList.add('termos-faltando');
      showErr('Você precisa aceitar os Termos de Uso.');
      return;
    }
    if (senha.value.length < 4) { showErr('A senha local precisa ter ao menos 4 caracteres.'); return; }

    btnLogin.disabled = true;
    btnLogin.textContent = 'Entrando...';

    fetch('/api/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        ra: ra, digito: $('digito').value, uf: ufInput.value, password: senha.value
      })
    })
      .then(function (r) { return r.json().then(function (d) { return { s: r.status, d: d }; }); })
      .then(function (res) {
        if (!res.d.ok) {
          showErr(res.d.error || 'Não foi possível entrar.');
          btnLogin.disabled = false;
          btnLogin.textContent = 'Entrar';
          return;
        }
        window.location.href = res.d.redirect || '/app';
      })
      .catch(function () {
        showErr('Erro de conexão. Tente novamente.');
        btnLogin.disabled = false;
        btnLogin.textContent = 'Entrar';
      });
  });

  /* ---------------- toasts ---------------- */
  function toast(msg, kind) {
    var wrap = document.querySelector('.toasts');
    if (!wrap) {
      wrap = document.createElement('div');
      wrap.className = 'toasts';
      document.body.appendChild(wrap);
    }
    var el = document.createElement('div');
    el.className = 'toast ' + (kind || '');
    el.textContent = msg;
    wrap.appendChild(el);
    setTimeout(function () {
      el.style.transition = 'opacity .3s';
      el.style.opacity = '0';
      setTimeout(function () { el.remove(); }, 320);
    }, 2600);
  }
})();
