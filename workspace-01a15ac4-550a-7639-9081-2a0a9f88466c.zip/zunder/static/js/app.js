/* Zunder — aplicativo (tarefas, redações, apostilas) */
(function () {
  'use strict';

  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };

  var state = {
    view: 'pendentes',
    tasks: [],
    filter: 'all',
    editingTask: null,
    essays: [],
    essayId: null,
    notes: [],
    noteId: null,
    noteTab: 'edit',
    scores: {}
  };

  /* ---------------- util ---------------- */
  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }

  function toast(msg, kind) {
    var wrap = $('.toasts');
    var el = document.createElement('div');
    el.className = 'toast ' + (kind || '');
    el.textContent = msg;
    wrap.appendChild(el);
    setTimeout(function () {
      el.style.transition = 'opacity .3s';
      el.style.opacity = '0';
      setTimeout(function () { el.remove(); }, 320);
    }, 2600);
  }

  function api(url, opts) {
    return fetch(url, Object.assign({
      headers: { 'Content-Type': 'application/json' }
    }, opts || {})).then(function (r) {
      return r.json().then(function (d) { return { s: r.status, d: d }; });
    });
  }

  function fmtDate(iso) {
    if (!iso) return 'Sem prazo';
    var p = iso.split('-');
    if (p.length !== 3) return iso;
    return p[2] + '/' + p[1] + '/' + p[0];
  }

  function dueLabel(t) {
    if (!t.due_date) return { text: 'Sem prazo', cls: '' };
    if (t.status === 'done') return { text: 'Entrega ' + fmtDate(t.due_date), cls: '' };
    var d = t.days_left;
    if (d === null) return { text: 'Entrega ' + fmtDate(t.due_date), cls: '' };
    if (d < 0) return { text: 'Atrasada há ' + Math.abs(d) + (Math.abs(d) === 1 ? ' dia' : ' dias'), cls: 'is-late' };
    if (d === 0) return { text: 'Vence hoje', cls: 'is-late' };
    if (d === 1) return { text: 'Vence amanhã', cls: 'is-soon' };
    return { text: 'Em ' + d + ' dias (' + fmtDate(t.due_date) + ')', cls: d <= 3 ? 'is-soon' : '' };
  }

  var PRIO = { 1: 'Prioridade alta', 2: 'Prioridade média', 3: 'Prioridade baixa' };

  /* ---------------- navegação ---------------- */
  $$('.nav-btn').forEach(function (btn) {
    btn.addEventListener('click', function () { go(btn.dataset.view); });
  });

  function go(view) {
    state.view = view;
    $$('.nav-btn').forEach(function (b) { b.classList.toggle('is-active', b.dataset.view === view); });
    ['pendentes', 'tarefas', 'redacoes', 'apostilas', 'sala'].forEach(function (v) {
      $('#view-' + v).hidden = (v !== view);
    });
    if (view === 'pendentes') loadPending();
    if (view === 'tarefas') loadTasks();
    if (view === 'redacoes' && !state.essays.length) loadEssays();
    if (view === 'apostilas' && !state.notes.length) loadNotes();
    if (view === 'sala') salaStatus();
    window.scrollTo(0, 0);
  }

  $('#btnRefreshPending').addEventListener('click', function () {
    loadPending();
    toast('Pendentes atualizados.', 'ok');
  });
  $('#btnGoSala').addEventListener('click', function () { go('sala'); });
  $('#btnLogout').addEventListener('click', function () {
    api('/api/logout', { method: 'POST' }).then(function () { window.location.href = '/'; });
  });

  /* ============================================================
     TAREFAS
     ============================================================ */

  function loadTasks() {
    Promise.all([api('/api/tasks'), api('/api/stats')]).then(function (res) {
      if (res[0].d.ok) { state.tasks = res[0].d.tasks; renderTasks(); }
      if (res[1].d.ok) { renderStats(res[1].d.stats); renderPlats(res[1].d.stats.by_platform); }
    });
  }

  function renderStats(s) {
    $('#statsGrid').innerHTML = [
      ['Total', s.total, 'atividades registradas', ''],
      ['Pendentes', s.pending, 'ainda não concluídas', ''],
      ['Atrasadas', s.overdue, 'prazo já passou', s.overdue ? 'is-danger' : ''],
      ['Próx. 3 dias', s.due_soon, 'vence em breve', s.due_soon ? 'is-warn' : ''],
      ['Concluídas', s.done, s.rate + '% de conclusão', s.done ? 'is-good' : '']
    ].map(function (x) {
      return '<div class="stat ' + x[3] + '"><div class="label">' + x[0] +
        '</div><div class="value">' + x[1] + '</div><div class="hint">' + x[2] + '</div></div>';
    }).join('') +
      '<div class="stat"><div class="label">Conclusões · 14 dias</div>' +
      '<div class="value">' + s.series.reduce(function (a, x) { return a + x.count; }, 0) + '</div>' +
      '<div class="spark">' + s.series.map(function (x) {
        var max = Math.max(1, Math.max.apply(null, s.series.map(function (y) { return y.count; })));
        var h = Math.max(2, Math.round(x.count / max * 100));
        return '<i style="height:' + h + '%" title="' + x.day + ': ' + x.count + '"></i>';
      }).join('') + '</div></div>';
  }

  function renderPlats(byPlatform) {
    var keys = Object.keys(byPlatform || {}).sort(function (a, b) {
      return byPlatform[b].total - byPlatform[a].total;
    });
    if (!keys.length) {
      $('#platGrid').innerHTML = '<div class="empty">Cadastre tarefas para ver o progresso por plataforma.</div>';
      return;
    }
    $('#platGrid').innerHTML = keys.map(function (k) {
      var v = byPlatform[k];
      var pct = v.total ? Math.round(v.done / v.total * 100) : 0;
      return '<div class="plat"><div class="p-name">' + esc(k) +
        '<span>' + v.done + '/' + v.total + '</span></div>' +
        '<div class="bar"><span style="width:' + pct + '%"></span></div></div>';
    }).join('');
  }

  function renderTasks() {
    var list = $('#taskList');
    var f = state.filter;
    var items = state.tasks.filter(function (t) {
      if (f === 'pending') return t.status !== 'done';
      if (f === 'done') return t.status === 'done';
      if (f === 'overdue') return t.overdue;
      if (f === 'soon') return t.status !== 'done' && t.days_left !== null && t.days_left >= 0 && t.days_left <= 3;
      return true;
    });

    if (!items.length) {
      list.innerHTML = '<div class="empty">' +
        '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 01-2 2H5a2 2 0 01-2-2V5a2 2 0 012-2h11"/></svg>' +
        '<div>Nada por aqui. Cadastre uma tarefa acima.</div></div>';
      return;
    }

    list.innerHTML = items.map(function (t) {
      var due = dueLabel(t);
      return '<div class="task ' + (t.status === 'done' ? 'is-done ' : '') + (t.overdue ? 'is-overdue' : '') + '" data-id="' + t.id + '">' +
        '<button class="tick ' + (t.status === 'done' ? 'is-on' : '') + '" data-act="toggle" aria-label="Concluir">' +
        '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6L9 17l-5-5"/></svg></button>' +
        '<div class="task-body">' +
        '<div class="task-title">' + esc(t.title) + '</div>' +
        (t.description ? '<div class="task-desc">' + esc(t.description) + '</div>' : '') +
        '<div class="task-meta">' +
        '<span class="tag tag-platform">' + esc(t.platform) + '</span>' +
        '<span class="tag">' + esc(t.subject) + '</span>' +
        '<span class="tag tag-due ' + due.cls + '">' + due.text + '</span>' +
        (t.priority !== 2 ? '<span class="tag tag-prio-' + t.priority + '">' + PRIO[t.priority] + '</span>' : '') +
        (t.grade ? '<span class="tag tag-grade">Nota ' + esc(t.grade) + '</span>' : '') +
        '</div></div>' +
        '<div class="task-actions">' +
        '<button class="icon-btn" data-act="edit" title="Editar"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/><path d="M18.5 2.5a2.12 2.12 0 013 3L12 15l-4 1 1-4z"/></svg></button>' +
        '<button class="icon-btn" data-act="grade" title="Registrar nota"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2l3 7h7l-5.5 4.5L18 21l-6-4-6 4 1.5-7.5L2 9h7z"/></svg></button>' +
        '<button class="icon-btn danger" data-act="del" title="Excluir"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18"/><path d="M8 6V4a2 2 0 012-2h4a2 2 0 012 2v2"/><path d="M19 6l-1 14a2 2 0 01-2 2H8a2 2 0 01-2-2L5 6"/></svg></button>' +
        '</div></div>';
    }).join('');
  }

  $$('#taskFilters .chip').forEach(function (c) {
    c.addEventListener('click', function () {
      $$('#taskFilters .chip').forEach(function (x) { x.classList.remove('is-active'); });
      c.classList.add('is-active');
      state.filter = c.dataset.filter;
      renderTasks();
    });
  });

  $('#taskList').addEventListener('click', function (e) {
    var btn = e.target.closest('[data-act]');
    if (!btn) return;
    var id = parseInt(e.target.closest('.task').dataset.id, 10);
    var act = btn.dataset.act;

    if (act === 'toggle') {
      var t = state.tasks.find(function (x) { return x.id === id; });
      api('/api/tasks/' + id, {
        method: 'PATCH',
        body: JSON.stringify({ status: t.status === 'done' ? 'pending' : 'done' })
      }).then(function (r) { if (r.d.ok) { toast('Atualizado.', 'ok'); loadTasks(); } });
    }

    if (act === 'del') {
      if (!confirm('Excluir esta tarefa?')) return;
      api('/api/tasks/' + id, { method: 'DELETE' })
        .then(function (r) { if (r.d.ok) { toast('Tarefa excluída.', 'ok'); loadTasks(); } });
    }

    if (act === 'grade') {
      var atual = state.tasks.find(function (x) { return x.id === id; });
      var v = prompt('Nota recebida (ex.: 8,5). Deixe vazio para remover.', atual.grade || '');
      if (v === null) return;
      api('/api/tasks/' + id, { method: 'PATCH', body: JSON.stringify({ grade: v.trim() || null }) })
        .then(function (r) { if (r.d.ok) { toast('Nota registrada.', 'ok'); loadTasks(); } });
    }

    if (act === 'edit') {
      var t2 = state.tasks.find(function (x) { return x.id === id; });
      state.editingTask = id;
      $('#tTitle').value = t2.title;
      $('#tPlatform').value = t2.platform;
      $('#tSubject').value = t2.subject;
      $('#tDue').value = t2.due_date || '';
      $('#tPriority').value = String(t2.priority);
      $('#tDesc').value = t2.description || '';
      $('#taskForm button[type=submit]').innerHTML = 'Salvar alterações';
      $('#btnCancelEdit').hidden = false;
      $('#tTitle').focus();
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  });

  var cancelBtn = document.createElement('button');
  cancelBtn.type = 'button';
  cancelBtn.className = 'btn-primary';
  cancelBtn.id = 'btnCancelEdit';
  cancelBtn.textContent = 'Cancelar';
  cancelBtn.style.marginLeft = '8px';
  cancelBtn.hidden = true;
  $('#taskForm').querySelector('div[style]').appendChild(cancelBtn);
  cancelBtn.addEventListener('click', function () { resetTaskForm(); });

  function resetTaskForm() {
    state.editingTask = null;
    $('#taskForm').reset();
    $('#taskForm button[type=submit]').innerHTML =
      '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 5v14M5 12h14"/></svg> Adicionar tarefa';
    cancelBtn.hidden = true;
  }

  $('#taskForm').addEventListener('submit', function (e) {
    e.preventDefault();
    var title = $('#tTitle').value.trim();
    if (!title) { toast('Dê um título à tarefa.', 'err'); return; }

    var payload = {
      title: title,
      platform: $('#tPlatform').value,
      subject: $('#tSubject').value,
      due_date: $('#tDue').value || null,
      priority: parseInt($('#tPriority').value, 10),
      description: $('#tDesc').value.trim()
    };

    var req = state.editingTask
      ? api('/api/tasks/' + state.editingTask, { method: 'PATCH', body: JSON.stringify(payload) })
      : api('/api/tasks', { method: 'POST', body: JSON.stringify(payload) });

    req.then(function (r) {
      if (!r.d.ok) { toast(r.d.error || 'Erro ao salvar.', 'err'); return; }
      toast(state.editingTask ? 'Tarefa atualizada.' : 'Tarefa adicionada.', 'ok');
      resetTaskForm();
      loadTasks();
    });
  });

  /* ============================================================
     REDAÇÕES
     ============================================================ */

  var REPERTORIO = [
    { cat: 'Filosofia', txt: 'Segundo Zygmunt Bauman, na "modernidade líquida" as relações e as certezas sociais tornam-se provisórias — imagem útil para falar de vínculos frágeis e responsabilidade coletiva.' },
    { cat: 'Filosofia', txt: 'Para Hannah Arendt, a "banalidade do mal" mostra que a violência cotidiana se sustenta na ausência de pensamento crítico.' },
    { cat: 'Sociologia', txt: 'Pierre Bourdieu explica a reprodução das desigualdades pelo conceito de "capital cultural": a escola, aparentemente neutra, valoriza o repertório de quem já tem mais acesso.' },
    { cat: 'Sociologia', txt: 'Para Émile Durkheim, a "anomia" é a perda de referências coletivas de conduta — chave para discutir desagregação social.' },
    { cat: 'História', txt: 'A Revolução Industrial consolidou a urbanização acelerada sem planejamento, criando passivos sanitários que até hoje marcam as periferias brasileiras.' },
    { cat: 'História', txt: 'A Constituição Federal de 1988, no artigo 6º, insere a educação entre os direitos sociais — o que torna a omissão estatal uma inconstitucionalidade, não apenas uma falha.' },
    { cat: 'Legislação', txt: 'O Estatuto da Criança e do Adolescente (Lei 8.069/1990), no artigo 4º, determina a prioridade absoluta na garantia de direitos fundamentais.' },
    { cat: 'Legislação', txt: 'A Lei de Diretrizes e Bases da Educação (Lei 9.394/1996) fixa a educação básica como direito público subjetivo, acionável judicialmente.' },
    { cat: 'Legislação', txt: 'O Marco Civil da Internet (Lei 12.965/2014) responsabiliza plataformas e abre caminho para discutir moderação e letramento digital.' },
    { cat: 'Legislação', txt: 'A Lei 14.811/2024 tipifica o bullying e o cyberbullying, reforçando o dever de proteção no ambiente escolar.' },
    { cat: 'Dados', txt: 'Segundo a PNAD Contínua do IBGE, a taxa de analfabetismo entre pessoas de 15 anos ou mais segue muito acima da média na faixa de 60 anos ou mais.' },
    { cat: 'Dados', txt: 'Dados do Censo Escolar do Inep mostram desigualdade persistente de infraestrutura entre escolas de diferentes regiões do país.' },
    { cat: 'Dados', txt: 'O Índice de Desenvolvimento da Educação Básica (Ideb) evidencia a distância de aprendizagem entre redes municipais, estaduais e privadas.' },
    { cat: 'Cultura', txt: 'No filme "Que Horas Ela Volta?" (2015), a piscina da casa dos patrões é interditada à filha da empregada — metáfora direta da exclusão por classe.' },
    { cat: 'Cultura', txt: '"Vidas Secas", de Graciliano Ramos, retrata a desumanização produzida pela seca e pela ausência de políticas públicas no Nordeste.' },
    { cat: 'Cultura', txt: 'A série "Cidade Invisível" (2021) associa a destruição ambiental à herança da colonização, útil para temas de sustentabilidade.' },
    { cat: 'Cultura', txt: 'Em "Capitães da Areia", Jorge Amado dá rosto à infância em situação de rua, tema ainda atual nas capitais brasileiras.' },
    { cat: 'Ciência', txt: 'Estudos sobre "determinantes sociais da saúde" mostram que renda, saneamento e escolaridade pesam mais sobre a expectativa de vida do que o acesso a hospitais.' },
    { cat: 'Ciência', txt: 'O conceito de "racismo estrutural", formulado por Silvio Almeida, desloca o foco da intenção individual para o funcionamento das instituições.' },
    { cat: 'Ciência', txt: 'Pesquisas em neurociência da aprendizagem indicam que sono e alimentação afetam diretamente o desempenho escolar — argumento para políticas de assistência estudantil.' },
    { cat: 'Geografia', txt: 'A "segregação socioespacial", discutida por Milton Santos, descreve como a cidade separa e hierarquiza seus habitantes pelo território.' },
    { cat: 'Geografia', txt: 'O "custo da invisibilidade" do trabalho doméstico remunerado no Brasil conecta herança escravocrata e desigualdade de gênero.' }
  ];

  var ESTRUTURA = [
    { key: 'intro', label: 'Introdução contextualiza o tema' },
    { key: 'tese', label: 'Tese explícita (o que será defendido)' },
    { key: 'd1', label: 'Desenvolvimento 1 com argumento central' },
    { key: 'd2', label: 'Desenvolvimento 2 com argumento complementar' },
    { key: 'conc', label: 'Conclusão retoma a tese' },
    { key: 'prop', label: 'Proposta de intervenção na conclusão' }
  ];

  var PROPOSTA = [
    { key: 'agente', label: '<b>Agente</b> — quem executa (Ministério, governo, escola, ONG...)' },
    { key: 'acao', label: '<b>Ação</b> — o que será feito (verbo no infinitivo)' },
    { key: 'meio', label: '<b>Meio/modo</b> — como (por meio de, através de...)' },
    { key: 'efeito', label: '<b>Efeito/finalidade</b> — para quê (a fim de, com o objetivo de...)' },
    { key: 'detalhe', label: '<b>Detalhamento</b> — informação extra que concretiza a ação' }
  ];

  var COMPETENCIAS = [
    { n: 1, t: 'Domínio da norma culta', d: 'Gramática, concordância, regência, pontuação e ortografia.' },
    { n: 2, t: 'Compreender a proposta', d: 'Aborda o tema pedido e aplica repertório de forma pertinente.' },
    { n: 3, t: 'Argumentação', d: 'Seleciona, organiza e interpreta informações em defesa de um ponto de vista.' },
    { n: 4, t: 'Coesão', d: 'Usa conectivos e encadeia as ideias com progressão lógica.' },
    { n: 5, t: 'Proposta de intervenção', d: 'Solução respeitando os direitos humanos, com os 5 elementos.' }
  ];

  var AGENTES = /\b(ministério|minist[ée]rio p[úu]blico|governo|estado|poder p[úu]blico|mec|secretaria|prefeitura|escola?s?|universidade|ong|organiza[çc][õo]es n[ãa]o governamentais|m[íi]dia|sociedade civil|conselho|defensoria|sus|institui[çc][õo]es)\b/i;
  var ACOES = /\b(criar|implementar|promover|garantir|ampliar|investir|fiscalizar|regulamentar|capacitar|conscientizar|elaborar|oferecer|disponibilizar|incentivar|reformular|assegurar|fortalecer|expandir|monitorar|punir|educar|incluir|integrar|difundir|construir|aplicar|destinar|reduzir|aumentar)\b/i;
  var MEIOS = /\b(por meio de|por interm[ée]dio de|atrav[ée]s de|mediante|via|com o uso de|a partir de|por via de|utilizando)\b/i;
  var EFEITOS = /\b(a fim de|para que|com o objetivo de|com o intuito de|de modo (a|que)|visando|de forma a|com a finalidade de|para)\b/i;

  function analisar(texto) {
    var paras = texto.split(/\n\s*\n|\n/).map(function (s) { return s.trim(); }).filter(Boolean);
    var ultimo = paras[paras.length - 1] || '';
    var penult = paras[paras.length - 2] || '';

    var prop = {
      agente: AGENTES.test(ultimo) || AGENTES.test(penult),
      acao: ACOES.test(ultimo),
      meio: MEIOS.test(ultimo),
      efeito: EFEITOS.test(ultimo),
      detalhe: ultimo.length > 260 || /,\s*(que|ao|aos|na|no|com|para|desde|porque|pois|visto|uma vez)\b/i.test(ultimo)
    };

    return {
      paras: paras.length,
      prop: prop,
      propOk: prop.agente && prop.acao && prop.meio && prop.efeito
    };
  }

  function loadEssays() {
    api('/api/essays').then(function (r) {
      if (!r.d.ok) return;
      state.essays = r.d.essays;
      renderEssayList();
      if (!state.essayId && state.essays.length) openEssay(state.essays[0].id);
      if (!state.essays.length && !state.essayId) newEssay();
    });
  }

  function renderEssayList() {
    $('#essayList').innerHTML = state.essays.map(function (e) {
      return '<div class="essay-item ' + (e.id === state.essayId ? 'is-active' : '') + '" data-id="' + e.id + '">' +
        '<div class="e-title">' + esc(e.theme || 'Redação sem tema') + '</div>' +
        '<div class="e-when">' + e.size + ' car.</div>' +
        '<button class="icon-btn danger" data-del="' + e.id + '" title="Excluir"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18"/><path d="M8 6V4a2 2 0 012-2h4a2 2 0 012 2v2"/><path d="M19 6l-1 14a2 2 0 01-2 2H8a2 2 0 01-2-2L5 6"/></svg></button>' +
        '</div>';
    }).join('') || '<div class="empty">Nenhuma redação ainda.</div>';

    $$('#essayList .essay-item').forEach(function (el) {
      el.addEventListener('click', function (e) {
        var del = e.target.closest('[data-del]');
        if (del) {
          e.stopPropagation();
          var id = parseInt(del.dataset.del, 10);
          if (!confirm('Excluir esta redação?')) return;
          api('/api/essays/' + id, { method: 'DELETE' }).then(function (r) {
            if (r.d.ok) {
              if (state.essayId === id) { state.essayId = null; $('#eTheme').value = ''; $('#eText').value = ''; updateEditor(); }
              toast('Redação excluída.', 'ok');
              loadEssays();
            }
          });
          return;
        }
        openEssay(parseInt(el.dataset.id, 10));
      });
    });
  }

  function openEssay(id) {
    api('/api/essays/' + id).then(function (r) {
      if (!r.d.ok) return;
      state.essayId = id;
      $('#eTheme').value = r.d.essay.theme || '';
      $('#eText').value = r.d.essay.content || '';
      renderEssayList();
      updateEditor();
    });
  }

  $('#btnNewEssay').addEventListener('click', newEssay);
  function newEssay() {
    api('/api/essays', { method: 'POST', body: JSON.stringify({ theme: '' }) }).then(function (r) {
      if (!r.d.ok) { toast('Erro ao criar.', 'err'); return; }
      state.essayId = r.d.id;
      $('#eTheme').value = '';
      $('#eText').value = '';
      loadEssays();
      updateEditor();
      $('#eTheme').focus();
    });
  }

  $('#btnSaveEssay').addEventListener('click', function () {
    if (!state.essayId) { newEssay(); return; }
    api('/api/essays/' + state.essayId, {
      method: 'PUT',
      body: JSON.stringify({ theme: $('#eTheme').value, content: $('#eText').value, status: 'draft' })
    }).then(function (r) {
      if (!r.d.ok) { toast('Erro ao salvar.', 'err'); return; }
      toast('Redação salva.', 'ok');
      loadEssays();
    });
  });

  function updateEditor() {
    var txt = $('#eText').value || '';
    var words = txt.split(/\s+/).filter(Boolean).length;
    var paras = txt.split(/\n\s*\n|\n/).map(function (s) { return s.trim(); }).filter(Boolean).length;
    var sents = txt.split(/[.!?]+/).map(function (s) { return s.trim(); }).filter(Boolean).length;
    var chars = txt.replace(/\s/g, '').length;

    $('#cWords').textContent = words;
    $('#cParas').textContent = paras;
    $('#cSents').textContent = sents;
    $('#cChars').textContent = chars;

    var range = $('#cRange');
    if (!words) { range.textContent = '—'; range.className = ''; }
    else if (words < 200) { range.textContent = 'Muito curta para o ENEM'; range.className = 'warn'; }
    else if (words < 280) { range.textContent = 'Curta — mire 300+'; range.className = 'warn'; }
    else if (words <= 600) { range.textContent = 'Faixa típica da redação do ENEM'; range.className = 'ok'; }
    else { range.textContent = 'Acima do habitual'; range.className = 'warn'; }

    var an = analisar(txt);
    var estado = JSON.parse(localStorage.getItem('zunder_struct_' + state.essayId) || '{}');

    $('#structCheck').innerHTML = ESTRUTURA.map(function (it) {
      var auto = false;
      if (it.key === 'intro') auto = an.paras >= 1;
      if (it.key === 'd1') auto = an.paras >= 2;
      if (it.key === 'd2') auto = an.paras >= 3;
      if (it.key === 'conc') auto = an.paras >= 4;
      if (it.key === 'prop') auto = an.propOk;
      var checked = estado[it.key] || (auto && estado[it.key] !== false);
      return '<label class="check-item' + (auto ? ' is-found' : '') + '">' +
        '<input type="checkbox" data-struct="' + it.key + '"' + (checked ? ' checked' : '') + ' />' +
        '<span>' + it.label + '</span></label>';
    }).join('');

    $('#propCheck').innerHTML = PROPOSTA.map(function (it) {
      return '<label class="check-item' + (an.prop[it.key] ? ' is-found' : '') + '">' +
        '<input type="checkbox" disabled' + (an.prop[it.key] ? ' checked' : '') + ' />' +
        '<span>' + it.label + '</span></label>';
    }).join('') +
      '<p style="font-size:11px;color:var(--text-muted);margin-top:8px;line-height:1.5">' +
      'Detecção automática por palavras-chave no último parágrafo — é um ' +
      'indício para você revisar, não uma correção oficial.</p>';

    $$('#structCheck input').forEach(function (inp) {
      inp.addEventListener('change', function () {
        var st = JSON.parse(localStorage.getItem('zunder_struct_' + state.essayId) || '{}');
        st[inp.dataset.struct] = inp.checked;
        localStorage.setItem('zunder_struct_' + state.essayId, JSON.stringify(st));
      });
    });
  }

  $('#eText').addEventListener('input', updateEditor);

  /* competências */
  function renderComp() {
    $('#compList').innerHTML = COMPETENCIAS.map(function (c) {
      var v = state.scores[c.n] || 0;
      var stars = '';
      for (var i = 1; i <= 5; i++) {
        stars += '<button data-c="' + c.n + '" data-v="' + i + '" class="' + (i <= v ? 'on' : '') +
          '" aria-label="Competência ' + c.n + ': ' + i + '"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2l3 7h7l-5.5 4.5L18 21l-6-4-6 4 1.5-7.5L2 9h7z"/></svg></button>';
      }
      return '<div class="comp"><h4>C' + c.n + ' · ' + esc(c.t) + '</h4>' +
        '<p>' + esc(c.d) + '</p><div class="comp-stars">' + stars + '</div></div>';
    }).join('');
  }

  $('#compList').addEventListener('click', function (e) {
    var b = e.target.closest('button[data-c]');
    if (!b) return;
    var c = b.dataset.c, v = parseInt(b.dataset.v, 10);
    state.scores[c] = (state.scores[c] === v) ? 0 : v;
    localStorage.setItem('zunder_scores_' + (state.essayId || 0), JSON.stringify(state.scores));
    renderComp();
  });

  /* repertório */
  function renderRep(filtro) {
    var f = (filtro || '').toLowerCase();
    var lista = REPERTORIO.filter(function (r) {
      return !f || r.txt.toLowerCase().indexOf(f) >= 0 || r.cat.toLowerCase().indexOf(f) >= 0;
    });
    $('#repList').innerHTML = lista.map(function (r, i) {
      return '<div class="rep"><div class="rep-cat">' + esc(r.cat) + '</div>' +
        '<div class="rep-txt">' + esc(r.txt) + '</div>' +
        '<div class="rep-act"><button data-rep="' + REPERTORIO.indexOf(r) + '">Inserir no texto</button></div></div>';
    }).join('') || '<div class="empty">Nada encontrado.</div>';

    $$('#repList button[data-rep]').forEach(function (b) {
      b.addEventListener('click', function () {
        var item = REPERTORIO[parseInt(b.dataset.rep, 10)];
        var el = $('#eText');
        var pos = el.selectionStart || el.value.length;
        var antes = el.value.slice(0, pos);
        var depois = el.value.slice(pos);
        var sep = (antes && !/\n$/.test(antes)) ? '\n\n' : '';
        el.value = antes + sep + item.txt + depois;
        el.focus();
        updateEditor();
        toast('Inserido — reescreva com as suas palavras.', 'ok');
      });
    });
  }

  $('#repSearch').addEventListener('input', function () { renderRep(this.value); });

  /* ============================================================
     APOSTILAS
     ============================================================ */

  function loadNotes() {
    api('/api/notes').then(function (r) {
      if (!r.d.ok) return;
      state.notes = r.d.notes;
      renderNotes();
      if (!state.noteId && state.notes.length) openNote(state.notes[0].id);
    });
  }

  function renderNotes() {
    var q = ($('#noteSearch').value || '').toLowerCase();
    var lista = state.notes.filter(function (n) {
      return !q || n.title.toLowerCase().indexOf(q) >= 0 ||
        n.content.toLowerCase().indexOf(q) >= 0 ||
        n.subject.toLowerCase().indexOf(q) >= 0;
    });
    $('#noteList').innerHTML = lista.map(function (n) {
      return '<div class="note-item ' + (n.id === state.noteId ? 'is-active' : '') + '" data-id="' + n.id + '">' +
        '<div class="n-title">' + esc(n.title) + '</div>' +
        '<div class="n-sub">' + esc(n.subject) + '</div></div>';
    }).join('') || '<div class="empty">Nenhuma anotação.</div>';

    $$('#noteList .note-item').forEach(function (el) {
      el.addEventListener('click', function () { openNote(parseInt(el.dataset.id, 10)); });
    });
  }

  function openNote(id) {
    var n = state.notes.find(function (x) { return x.id === id; });
    if (!n) return;
    state.noteId = id;
    $('#nTitle').value = n.title;
    $('#nSubject').value = n.subject;
    $('#nText').value = n.content;
    renderNotes();
    renderPreview();
  }

  $('#btnNewNote').addEventListener('click', function () {
    api('/api/notes', { method: 'POST', body: JSON.stringify({ title: 'Nova anotação' }) })
      .then(function (r) {
        if (!r.d.ok) { toast('Erro ao criar.', 'err'); return; }
        loadNotes();
        setTimeout(function () { openNote(r.d.id); $('#nTitle').select(); }, 200);
      });
  });

  $('#btnSaveNote').addEventListener('click', function () {
    if (!state.noteId) { toast('Selecione ou crie uma anotação.', 'err'); return; }
    api('/api/notes/' + state.noteId, {
      method: 'PUT',
      body: JSON.stringify({
        title: $('#nTitle').value.trim() || 'Sem título',
        subject: $('#nSubject').value,
        content: $('#nText').value
      })
    }).then(function (r) {
      if (!r.d.ok) { toast('Erro ao salvar.', 'err'); return; }
      toast('Anotação salva.', 'ok');
      loadNotes();
    });
  });

  $('#btnDelNote').addEventListener('click', function () {
    if (!state.noteId) return;
    if (!confirm('Excluir esta anotação?')) return;
    api('/api/notes/' + state.noteId, { method: 'DELETE' }).then(function (r) {
      if (r.d.ok) {
        state.noteId = null;
        $('#nTitle').value = ''; $('#nText').value = '';
        renderPreview();
        toast('Anotação excluída.', 'ok');
        loadNotes();
      }
    });
  });

  $('#noteSearch').addEventListener('input', renderNotes);

  $$('#view-apostilas .tabs-mini button').forEach(function (b) {
    b.addEventListener('click', function () {
      $$('#view-apostilas .tabs-mini button').forEach(function (x) { x.classList.remove('is-active'); });
      b.classList.add('is-active');
      state.noteTab = b.dataset.noteTab;
      var edit = state.noteTab === 'edit';
      $('#nText').hidden = !edit;
      $('#nPreview').hidden = edit;
      if (!edit) renderPreview();
    });
  });

  $('#nText').addEventListener('input', function () { if (state.noteTab === 'view') renderPreview(); });

  function md(src) {
    var lines = esc(src).split('\n');
    var out = [], inList = false, inOl = false;

    function closeLists() {
      if (inList) { out.push('</ul>'); inList = false; }
      if (inOl) { out.push('</ol>'); inOl = false; }
    }

    lines.forEach(function (raw) {
      var line = raw.trim();
      if (!line) { closeLists(); return; }
      if (/^---+$/.test(line)) { closeLists(); out.push('<hr>'); return; }

      var h = line.match(/^(#{1,6})\s+(.*)$/);
      if (h) { closeLists(); var lvl = h[1].length; out.push('<h' + lvl + '>' + inline(h[2]) + '</h' + lvl + '>'); return; }

      var bq = line.match(/^&gt;\s?(.*)$/);
      if (bq) { closeLists(); out.push('<blockquote>' + inline(bq[1]) + '</blockquote>'); return; }

      var ul = line.match(/^[-*+]\s+(.*)$/);
      if (ul) { if (inOl) { out.push('</ol>'); inOl = false; } if (!inList) { out.push('<ul>'); inList = true; } out.push('<li>' + inline(ul[1]) + '</li>'); return; }

      var ol = line.match(/^\d+\.\s+(.*)$/);
      if (ol) { if (inList) { out.push('</ul>'); inList = false; } if (!inOl) { out.push('<ol>'); inOl = true; } out.push('<li>' + inline(ol[1]) + '</li>'); return; }

      closeLists();
      out.push('<p>' + inline(line) + '</p>');
    });

    closeLists();
    return out.join('');

    function inline(s) {
      return s
        .replace(/`([^`]+)`/g, '<code>$1</code>')
        .replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>')
        .replace(/(^|\W)\*([^*]+)\*/g, '$1<em>$2</em>')
        .replace(/(^|\W)_([^_]+)_/g, '$1<em>$2</em>')
        .replace(/~~([^~]+)~~/g, '<del>$1</del>');
    }
  }

  function renderPreview() {
    $('#nPreview').innerHTML = md($('#nText').value || '');
  }

  /* ============================================================
     boot
     ============================================================ */

  api('/api/me').then(function (r) {
    if (!r.d.ok) { window.location.href = '/'; return; }
    $('#raLabel').textContent = r.d.user.ra + (r.d.user.digito ? '-' + r.d.user.digito : '') + '/' + r.d.user.uf;
    var saved = localStorage.getItem('zunder_scores_0');
    if (saved) { try { state.scores = JSON.parse(saved); } catch (e) { state.scores = {}; } }
    renderComp();
    renderRep('');
    loadPending();
    loadTasks();
    loadEssays();
    loadNotes();
    updateEditor();
  });

  /* atalho: ctrl+s salva o que estiver aberto */
  document.addEventListener('keydown', function (e) {
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's') {
      e.preventDefault();
      if (state.view === 'redacoes') $('#btnSaveEssay').click();
      else if (state.view === 'apostilas') $('#btnSaveNote').click();
      else $('#taskForm').requestSubmit ? $('#taskForm').requestSubmit() : null;
    }
  });
/* ============================================================
   Módulo: Pendentes
   ============================================================ */
var pendingData = null;
var checkedItems = {};

function loadPending() {
  api('/api/pending').then(function (r) {
    if (!r.d.ok) return;
    pendingData = r.d.pending;
    renderPending(pendingData);
  });
}

function renderPending(p) {
  $('#pendingStats').innerHTML = [
    ['Pendentes', p.total, 'no total', ''],
    ['Atrasadas', p.atrasadas, 'prazo vencido', p.atrasadas ? 'is-danger' : ''],
    ['Vencem hoje', p.hoje, 'para entregar hoje', p.hoje ? 'is-warn' : ''],
    ['Próx. 7 dias', p.semana, 'entre 1 e 7 dias', p.semana ? 'is-warn' : '']
  ].map(function (x) {
    return '<div class="stat ' + x[3] + '"><div class="label">' + x[0] +
      '</div><div class="value">' + x[1] + '</div><div class="hint">' + x[2] + '</div></div>';
  }).join('');

  // por plataforma
  var keys = Object.keys(p.por_plataforma || {}).sort(function (a, b) {
    return p.por_plataforma[b].total - p.por_plataforma[a].total;
  });
  if (!keys.length) {
    $('#pendingPlatforms').innerHTML = '<div class="empty">Nenhuma tarefa pendente. ' +
      'Cadastre em Tarefas ou busque na Sala do Futuro.</div>';
  } else {
    $('#pendingPlatforms').innerHTML = keys.map(function (k) {
      var v = p.por_plataforma[k];
      var max = Math.max.apply(null, keys.map(function (x) { return p.por_plataforma[x].total; }));
      var pct = Math.round(v.total / max * 100);
      return '<div class="plat"><div class="p-name">' + esc(k) +
        '<span>' + v.total + ' pendente' + (v.total === 1 ? '' : 's') + '</span></div>' +
        '<div class="bar"><span style="width:' + pct + '%"></span></div>' +
        '<div class="plat-extra">' +
        (v.atrasadas ? '<span class="tag tag-due is-late">' + v.atrasadas + ' atrasada' + (v.atrasadas === 1 ? '' : 's') + '</span> ' : '') +
        (v.semana ? '<span class="tag tag-due is-soon">' + v.semana + ' nesta semana</span>' : '') +
        '</div></div>';
    }).join('');
  }
  $('#pendingNote').textContent = 'Atualizado em ' + p.gerado_em +
    '. Os números vêm do que está registrado neste aplicativo.';

  // quadro de prazos
  var faixas = [
    ['atrasadas', 'Atrasadas', true],
    ['hoje', 'Vence hoje', false],
    ['3dias', 'Próx. 3 dias', false],
    ['7dias', 'Próx. 7 dias', false],
    ['depois', 'Mais de 7 dias', false],
    ['sem_prazo', 'Sem prazo', false]
  ];
  $('#pendingBoard').innerHTML = faixas.map(function (f) {
    var itens = p.faixas[f[0]] || [];
    return '<div class="board-col' + (f[2] ? ' is-late' : '') + '">' +
      '<h4>' + f[1] + ' <b>' + itens.length + '</b></h4>' +
      (itens.length ? itens.map(function (t) {
        var d = t.due_date ? fmtDate(t.due_date) : 'sem prazo';
        return '<div class="board-item"><div class="bi-title">' + esc(t.title) + '</div>' +
          '<div class="bi-meta">' + esc(t.platform) + ' · ' + d + '</div></div>';
      }).join('') : '<div class="empty" style="padding:14px 6px;font-size:12px">vazio</div>') +
      '</div>';
  }).join('');
}

/* ============================================================
   Módulo: Sala do Futuro (captura somente-leitura)
   ============================================================ */
var sala = { capture: null, tab: 'itens' };

function salaStatus(msg, kind) {
  var el = $('#salaStatus');
  if (msg && !kind) { el.innerHTML = msg; el.className = 'sala-status'; return; }
  api('/api/sala/status').then(function (r) {
    var d = r.d;
    el.className = 'sala-status';
    if (d.offline) {
      el.className = 'sala-status is-err';
      el.innerHTML = '<b>Servidor de captura offline.</b><br>' + esc(d.error) +
        '<br><code>cd sala-playwright &amp;&amp; npm start</code>';
      return;
    }
    if (!d.open) {
      el.className = 'sala-status is-warn';
      el.innerHTML = 'Navegador fechado. Clique em <b>Abrir portal</b> para começar.';
      return;
    }
    el.className = 'sala-status ' + (d.allowed ? 'is-ok' : 'is-err');
    el.innerHTML = '<b>Navegador aberto</b><br>' +
      'Página: <code>' + esc(d.url || '(vazia)') + '</code><br>' +
      'Título: ' + esc(d.title || '—') + '<br>' +
      (d.allowed ? 'Domínio permitido para captura.' : 'Domínio fora da lista de permissão.') +
      (d.selector ? '<br>Seletor salvo: <code>' + esc(d.selector) + '</code>' : '');
  });
}

$('#btnSalaOpen').addEventListener('click', function () {
  var b = this; b.disabled = true; b.textContent = 'Abrindo...';
  api('/api/sala/open', { method: 'POST', body: JSON.stringify({}) }).then(function (r) {
    b.disabled = false; b.textContent = 'Abrir portal';
    if (r.d.offline) { salaStatus(); toast(r.d.error, 'err'); return; }
    if (!r.d.ok) { toast(r.d.error || 'Falha ao abrir.', 'err'); return; }
    toast('Navegador aberto. Faça login e navegue até a página desejada.', 'ok');
    salaStatus();
  });
});

$('#btnSalaStatus').addEventListener('click', function () { salaStatus(); });

$('#btnSalaClose').addEventListener('click', function () {
  if (!confirm('Fechar o navegador? A sessão será encerrada e o perfil temporário apagado.')) return;
  api('/api/sala/close', { method: 'POST', body: JSON.stringify({}) }).then(function () {
    toast('Navegador fechado.', 'ok'); salaStatus();
  });
});

function doCapture() {
  var sel = $('#salaSelector').value;
  var plat = $('#salaPlatform').value;
  var payload = { selector: sel || null, platform: plat || null, use_saved: true };
  $('#btnSalaCapture').disabled = true;
  $('#btnSalaCapture').textContent = 'Capturando...';
  api('/api/sala/capture', { method: 'POST', body: JSON.stringify(payload) }).then(function (r) {
    $('#btnSalaCapture').disabled = false;
    $('#btnSalaCapture').textContent = 'Capturar página atual';
    var d = r.d;
    if (d.offline) { salaStatus(); toast(d.error, 'err'); return; }
    if (!d.ok) { toast(d.error || 'Falha na captura.', 'err'); salaStatus(); return; }
    sala.capture = d;
    renderCapture(d);
    toast('Capturado: ' + d.resumo.total + ' item(ns), ' + d.resumo.pendentes + ' pendente(s).', 'ok');
  });
}
$('#btnSalaCapture').addEventListener('click', doCapture);
$('#btnSalaRecapture').addEventListener('click', doCapture);

function renderCapture(d) {
  $('#cardSalaResult').hidden = false;

  $('#salaResumo').innerHTML =
    'Página: <code>' + esc(d.url) + '</code><br>' +
    'Estrutura usada: <code>' + esc(d.selector || '—') + '</code> (' + esc(d.kind || '—') + ')<br>' +
    'Plataforma detectada: <b>' + esc(d.plataforma || 'nenhuma') + '</b><br>' +
    '<b>' + d.resumo.total + '</b> item(ns) · <b>' + d.resumo.pendentes +
    '</b> pendente(s) · <b>' + d.resumo.atrasadas + '</b> atrasada(s) · ' +
    '<b>' + d.resumo.concluidas + '</b> concluída(s)';

  // seletor: candidatos descobertos + salvo
  var sel = $('#salaSelector');
  var atual = d.selector;
  sel.innerHTML = '<option value="">Automático (melhor palpite)</option>' +
    (d.candidates || []).map(function (c) {
      return '<option value="' + esc(c.selector) + '"' + (c.selector === atual ? ' selected' : '') + '>' +
        esc(c.kind) + ' · ' + c.count + ' itens · score ' + c.score +
        ' — ' + esc((c.sample || '').slice(0, 60)) + '</option>';
    }).join('');
  if (atual) sel.value = atual;

  $('#salaPlatform').value = d.plataforma || '';

  // itens
  checkedItems = {};
  $('#salaItems').innerHTML = (d.items || []).map(function (it, i) {
    checkedItems[i] = it.status !== 'done';
    var tags = [];
    if (it.due_date) tags.push('<span class="tag tag-due">' + fmtDate(it.due_date) + '</span>');
    if (it.platform) tags.push('<span class="tag tag-platform">' + esc(it.platform) + '</span>');
    if (it.subject) tags.push('<span class="tag">' + esc(it.subject) + '</span>');
    var st = it.status === 'late' ? '<span class="tag tag-due is-late">atrasada</span>'
      : it.status === 'done' ? '<span class="tag">concluída</span>'
      : it.status === 'pending' ? '<span class="tag tag-due is-soon">pendente</span>' : '';
    return '<div class="sala-item">' +
      '<input type="checkbox" data-idx="' + i + '"' + (it.status !== 'done' ? ' checked' : '') + ' />' +
      '<div class="si-body"><div class="si-title">' + esc(it.title) + '</div>' +
      '<div class="si-meta">' + st + tags.join('') + '</div></div></div>';
  }).join('') || '<div class="empty">Nada encontrado nesta página. ' +
    'Tente outra estrutura no campo acima ou navegue até a lista de tarefas.</div>';

  $$('#salaItems input[data-idx]').forEach(function (cb) {
    cb.addEventListener('change', function () { checkedItems[cb.dataset.idx] = cb.checked; });
  });

  dumpTab();
}

$$('#view-sala .tabs-mini button[data-sala-tab]').forEach(function (b) {
  b.addEventListener('click', function () {
    $$('#view-sala .tabs-mini button[data-sala-tab]').forEach(function (x) { x.classList.remove('is-active'); });
    b.classList.add('is-active');
    sala.tab = b.dataset.salaTab;
    dumpTab();
  });
});

function dumpTab() {
  var d = sala.capture;
  if (!d) return;
  var el = $('#salaDump');
  if (sala.tab === 'json') {
    el.textContent = JSON.stringify({
      url: d.url, title: d.title, capturedAt: d.capturedAt,
      plataforma: d.plataforma, selector: d.selector,
      resumo: d.resumo, items: d.items
    }, null, 2);
    var blob = new Blob([el.textContent], { type: 'application/json' });
    var a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'sala-do-futuro-' + Date.now() + '.json';
    a.textContent = 'Baixar JSON';
    el.innerHTML = '';
    el.appendChild(a);
    return;
  }
  if (sala.tab === 'itens') el.textContent = (d.items || []).map(function (i, n) {
    return (n + 1) + '. ' + i.title + '\n   prazo: ' + (i.due_date || '—') +
      ' | status: ' + i.status + ' | plataforma: ' + (i.platform || '—') +
      ' | matéria: ' + (i.subject || '—');
  }).join('\n');
  else if (sala.tab === 'texto') el.textContent = d.text || '';
  else el.textContent = d.html || '';
}

$('#btnSalaImport').addEventListener('click', function () {
  var d = sala.capture;
  if (!d || !d.items) { toast('Capture uma página primeiro.', 'err'); return; }
  var escolhidos = (d.items || []).filter(function (_, i) { return checkedItems[i]; });
  if (!escolhidos.length) { toast('Nenhum item selecionado.', 'err'); return; }

  api('/api/sala/import', {
    method: 'POST',
    body: JSON.stringify({
      items: escolhidos,
      only_pending: $('#salaOnlyPending').checked,
      platform: $('#salaPlatform').value || d.plataforma || 'TarefaSP'
    })
  }).then(function (r) {
    if (!r.d.ok) { toast('Erro ao importar.', 'err'); return; }
    toast(r.d.criadas + ' tarefa(s) criada(s), ' + r.d.ignoradas + ' ignorada(s).', 'ok');
    // salva o seletor que funcionou
    if ($('#salaSelector').value) {
      api('/api/sala/selector', {
        method: 'POST',
        body: JSON.stringify({
          selector: $('#salaSelector').value,
          platform: $('#salaPlatform').value
        })
      });
    }
    loadPending();
    go('pendentes');
  });
});

})();
