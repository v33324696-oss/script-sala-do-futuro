'use strict';

/**
 * Servidor de captura da Sala do Futuro (somente leitura).
 *
 * Como funciona:
 *   1. O servidor abre um Chromium VISIVEL controlado pelo Playwright.
 *   2. VOCE faz login manualmente e navega ate a pagina que quer consultar.
 *   3. O Zunder manda capturar -> este servidor LE o DOM e devolve
 *      texto + HTML higienizado + os itens ja estruturados.
 *
 * O que este servidor NAO faz, por construcao:
 *   - nao recebe, nao guarda e nao transmite senha nenhuma (quem digita e voce)
 *   - nao preenche formulario, nao clica em botao, nao envia resposta
 *   - nao persiste cookie nem sessao: o perfil e temporario e apagado ao fechar
 *   - so captura dentro dos dominios da lista de permissao
 */

const http = require('http');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { chromium } = require('playwright');
const { collect, inferPlatform } = require('./extract');

const PORT = Number(process.env.PORT || 8765);
const HOST = process.env.HOST || '127.0.0.1';
const HEADLESS = process.env.HEADLESS === '1';

const START_URL = process.env.START_URL || 'https://saladofuturo.educacao.sp.gov.br/';

// Somente dominios da Seduc-SP. Nada fora disso e capturado.
const ALLOWED = (process.env.ALLOWED_DOMAINS ||
  'educacao.sp.gov.br,saladofuturo.educacao.sp.gov.br')
  .split(',').map((s) => s.trim().toLowerCase()).filter(Boolean);

// ------------------------------------------------------------- estado

let ctx = null;
let profileDir = null;
let lastError = null;

function hostOf(url) {
  try { return new URL(url).hostname.toLowerCase(); } catch (_) { return ''; }
}

function allowed(url) {
  const h = hostOf(url);
  if (!h) return false;
  return ALLOWED.some((d) => h === d || h.endsWith('.' + d));
}

async function page() {
  if (!ctx) return null;
  const pages = ctx.pages().filter((p) => !p.isClosed());
  if (!pages.length) return await ctx.newPage();
  // ultima pagina ativa, ignorando about:blank
  return pages.filter((p) => p.url() && p.url() !== 'about:blank').pop() || pages[0];
}

// ------------------------------------------------------- higienizacao

function sanitize(html) {
  return String(html || '')
    // blocos inteiros
    .replace(/<script\b[\s\S]*?<\/script>/gi, '')
    .replace(/<iframe\b[\s\S]*?<\/iframe>/gi, '')
    .replace(/<object\b[\s\S]*?<\/object>/gi, '')
    .replace(/<embed\b[\s\S]*?<\/embed>/gi, '')
    .replace(/<noscript\b[\s\S]*?<\/noscript>/gi, '')
    .replace(/<style\b[\s\S]*?<\/style>/gi, '')
    .replace(/<svg\b[\s\S]*?<\/svg>/gi, '')
    // manipuladores de evento
    .replace(/\son[a-z]+\s*=\s*"[^"]*"/gi, '')
    .replace(/\son[a-z]+\s*=\s*'[^']*'/gi, '')
    // valores de formulario ( inclusive senha )
    .replace(/<input\b[^>]*>/gi, (m) =>
      m.replace(/\s(?:value|checked|selected)\s*=\s*"[^"]*"/gi, '')
        .replace(/\s(?:value|checked|selected)\s*=\s*'[^']*'/gi, '')
        .replace(/\stype\s*=\s*["']?password["']?/gi, ' type="text"')
    )
    .replace(/(<textarea\b[^>]*>)[\s\S]*?(<\/textarea>)/gi, '$1$2')
    // urls javascript:
    .replace(/(href|src)\s*=\s*["']\s*javascript:[^"']*["']/gi, '$1="#"')
    .trim();
}

function stripText(html) {
  return sanitize(html)
    .replace(/<br\s*\/?>/gi, '\n')
    .replace(/<\/(p|div|li|tr|h[1-6]|section|article)>/gi, '\n')
    .replace(/<[^>]+>/g, ' ')
    .replace(/&nbsp;/gi, ' ')
    .replace(/&amp;/gi, '&')
    .replace(/&lt;/gi, '<')
    .replace(/&gt;/gi, '>')
    .replace(/&quot;/gi, '"')
    .replace(/[ \t]+/g, ' ')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}

// --------------------------------------------------------------- rotas

function send(res, code, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(code, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(body),
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
  });
  res.end(body);
}

function readJson(req) {
  return new Promise((resolve) => {
    let raw = '';
    req.on('data', (c) => { raw += c; if (raw.length > 2_000_000) req.destroy(); });
    req.on('end', () => {
      try { resolve(raw ? JSON.parse(raw) : {}); } catch (_) { resolve({}); }
    });
    req.on('error', () => resolve({}));
  });
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://' + (req.headers.host || 'localhost'));
  const route = url.pathname;

  if (req.method === 'OPTIONS') return send(res, 204, {});

  try {
    if (route === '/health') {
      return send(res, 200, { ok: true, open: !!ctx, headless: HEADLESS, allowed: ALLOWED, start: START_URL });
    }

    if (route === '/open' && req.method === 'POST') {
      const body = await readJson(req);
      if (ctx) {
        const p = await page();
        return send(res, 200, { ok: true, already: true, url: p ? p.url() : null });
      }
      profileDir = fs.mkdtempSync(path.join(os.tmpdir(), 'zunder-sala-'));
      ctx = await chromium.launchPersistentContext(profileDir, {
        headless: HEADLESS,
        args: ['--no-sandbox', '--disable-blink-features=AutomationControlled'],
        viewport: { width: 1280, height: 900 },
        locale: 'pt-BR',
      });
      ctx.on('close', () => { ctx = null; });
      const p = ctx.pages()[0] || await ctx.newPage();

      const target = body.url && allowed(body.url) ? body.url : START_URL;
      if (!allowed(target)) {
        await ctx.close(); ctx = null;
        return send(res, 400, { ok: false, error: 'Dominio nao permitido: ' + target });
      }
      try { await p.goto(target, { waitUntil: 'domcontentloaded', timeout: 30000 }); }
      catch (e) { lastError = 'Falha ao abrir: ' + e.message; }

      return send(res, 200, { ok: true, url: p.url(), headless: HEADLESS, message: HEADLESS ?
        'Navegador aberto em modo headless.' : 'Navegador aberto. Faca login manualmente e navegue ate a pagina desejada.' });
    }

    if (route === '/status' && req.method === 'GET') {
      if (!ctx) return send(res, 200, { ok: true, open: false, lastError });
      const p = await page();
      const u = p ? p.url() : '';
      let title = '';
      try { title = p ? await p.title() : ''; } catch (_) {}
      return send(res, 200, {
        ok: true, open: true, url: u, title,
        allowed: allowed(u), pages: ctx.pages().length, lastError,
      });
    }

    if (route === '/goto' && req.method === 'POST') {
      if (!ctx) return send(res, 409, { ok: false, error: 'Navegador fechado. Abra o portal primeiro.' });
      const body = await readJson(req);
      if (!body.url || !allowed(body.url)) {
        return send(res, 400, { ok: false, error: 'Dominio nao permitido.' });
      }
      const p = await page();
      await p.goto(body.url, { waitUntil: 'domcontentloaded', timeout: 30000 });
      return send(res, 200, { ok: true, url: p.url() });
    }

    if (route === '/capture' && req.method === 'POST') {
      if (!ctx) return send(res, 409, { ok: false, error: 'Navegador fechado. Abra o portal primeiro.' });
      const body = await readJson(req);
      const p = await page();
      if (!p) return send(res, 409, { ok: false, error: 'Nenhuma pagina aberta.' });

      const u = p.url();
      if (!u || u === 'about:blank') {
        return send(res, 400, { ok: false, error: 'Abra uma pagina da Sala do Futuro antes de capturar.' });
      }
      if (!allowed(u)) {
        return send(res, 403, { ok: false, error: 'Pagina fora dos dominios permitidos: ' + u });
      }

      const html = await p.content();
      const text = await p.evaluate(() => document.body ? document.body.innerText : '');

      // plataforma: a da pagina, ou a que o usuario escolheu na interface
      const inferida = await inferPlatform(p);
      const plataforma = body.platform || inferida || null;

      const result = await collect(p, {
        selector: body.selector || null,
        defaultPlatform: plataforma,
      });

      // conta o que parece pendente
      const pendentes = result.items.filter((i) => i.status === 'pending' || i.status === 'late');

      return send(res, 200, {
        ok: true,
        url: u,
        title: await p.title().catch(() => ''),
        capturedAt: new Date().toISOString(),
        html: sanitize(html),
        text: String(text || '').slice(0, 200000),
        candidates: result.candidates,
        embedded: result.embedded || [],
        items: result.items,
        selector: result.selector,
        kind: result.kind,
        plataforma: plataforma,
        plataformaInferida: inferida,
        resumo: {
          total: result.items.length,
          pendentes: pendentes.length,
          atrasadas: result.items.filter((i) => i.status === 'late').length,
          concluidas: result.items.filter((i) => i.status === 'done').length,
        },
      });
    }

    if (route === '/close' && req.method === 'POST') {
      if (ctx) { try { await ctx.close(); } catch (_) {} }
      ctx = null;
      if (profileDir) {
        try { fs.rmSync(profileDir, { recursive: true, force: true }); } catch (_) {}
        profileDir = null;
      }
      return send(res, 200, { ok: true, closed: true });
    }

    return send(res, 404, { ok: false, error: 'rota nao encontrada: ' + route });
  } catch (e) {
    lastError = e.message;
    return send(res, 500, { ok: false, error: e.message });
  }
});

server.listen(PORT, HOST, () => {
  console.log('Zunder · captura da Sala do Futuro');
  console.log('  ouvindo em  http://' + HOST + ':' + PORT);
  console.log('  dominios permitidos: ' + ALLOWED.join(', '));
  console.log('  modo: ' + (HEADLESS ? 'headless' : 'visivel (voce faz login manualmente)'));
  console.log('  somente leitura: nao preenche formulario nem envia resposta');
});

function shutdown() {
  if (ctx) { try { ctx.close(); } catch (_) {} }
  if (profileDir) { try { fs.rmSync(profileDir, { recursive: true, force: true }); } catch (_) {} }
  process.exit(0);
}
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);
