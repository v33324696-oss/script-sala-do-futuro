#!/usr/bin/env bash
# Sobe o servidor de captura da Sala do Futuro.
set -e
cd "$(dirname "$0")"

if [ ! -d node_modules ]; then
  echo "Instalando dependencias..."
  npm install
fi

if [ -z "$PLAYWRIGHT_BROWSERS_PATH" ] && [ ! -d "$HOME/.cache/ms-playwright" ]; then
  echo "Baixando o Chromium do Playwright..."
  npx playwright install chromium || {
    echo ""
    echo "Nao consegui instalar na pasta padrao. Tente:"
    echo "  export PLAYWRIGHT_BROWSERS_PATH=\"\$HOME/.playwright-browsers\""
    echo "  npx playwright install chromium"
    echo "  ./start.sh"
    exit 1
  }
fi

echo ""
echo "Abrindo em modo VISIVEL para voce fazer login manualmente."
echo "Para rodar sem janela: HEADLESS=1 ./start.sh"
echo ""
exec node server.js
