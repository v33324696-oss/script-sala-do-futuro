# Captura da Sala do Futuro — somente leitura

Módulo que abre um navegador Chromium controlado pelo Playwright, deixa
**você** fazer login e navegar, e então **lê** a página e devolve o conteúdo
estruturado (tarefas, prazos, status) para o Zunder.

```
sala-playwright/
├── server.js     # servidor HTTP (porta 8765) — controle do navegador
├── extract.js    # extrator adaptativo — descobre a estrutura sozinho
└── package.json
```

## Como usar

```bash
cd sala-playwright
npm install
npx playwright install chromium
npm start
```

Depois abra o Zunder (`python3 app.py`, porta 5000), entre e vá em
**Sala do Futuro**.

Se o Playwright reclamar de permissão para instalar os navegadores, aponte
para uma pasta sua:

```bash
export PLAYWRIGHT_BROWSERS_PATH="$HOME/.playwright-browsers"
npx playwright install chromium
```

### Variáveis de ambiente

| Variável | Padrão | Para que serve |
|---|---|---|
| `PORT` | `8765` | porta do servidor de captura |
| `HEADLESS` | não definido | `HEADLESS=1` abre sem janela (não dá para fazer login) |
| `START_URL` | `https://saladofuturo.educacao.sp.gov.br/` | página inicial ao abrir o portal |
| `ALLOWED_DOMAINS` | `educacao.sp.gov.br,saladofuturo.educacao.sp.gov.br` | lista de permissão — só esses domínios são capturados |

## O fluxo, passo a passo

1. **Abrir portal** — o servidor abre um Chromium visível na Sala do Futuro.
2. **Você** digita seu RA e senha direto no portal e navega até a página que
   quer consultar (TarefaSP, por exemplo).
3. **Capturar página atual** — o servidor lê o DOM da página aberta.
4. O extrator devolve os itens já estruturados; você confere a lista.
5. **Importar para Tarefas** — os itens entram no Zunder e passam a contar na
   tela **Pendentes**.

## Como o extrator funciona sem conhecer o HTML

O HTML da Sala do Futuro não é público e muda com o tempo. Em vez de embutir
seletores chutados, o `extract.js` **descobre** a estrutura em tempo real:

1. varre o DOM procurando **conjuntos de elementos que se repetem** (é sempre
   assim que listas de tarefas são construídas)
2. pontua cada conjunto por: quantidade de itens, tamanho médio do texto,
   presença de data, presença de palavras de status (pendente, atrasada,
   concluída) e presença de nome de plataforma
3. ranqueia e usa o melhor palpite
4. mostra os candidatos na interface — **você escolhe o certo uma vez** e o
   seletor fica salvo para as próximas capturas

Também detecta tabelas (`<table><tr>`), listas (`<ul><li>`), cartões
(`<div class="...">`) e JSON embutido (`__NEXT_DATA__`, `ld+json`).

O que ele extrai por item: **título**, **prazo** (vários formatos de data),
**status**, **matéria** e **plataforma**.

## Garantias do código

O servidor é somente-leitura **por construção**, não por promessa:

- ❌ não existe nenhuma chamada a `page.fill()`, `page.click()` ou
  `page.type()` — o login é digitado por você, com seu teclado, no portal
- ❌ não recebe, não armazena e não transmite senha: ela nunca chega a este
  processo
- ❌ não envia formulário nem submete resposta de atividade
- ❌ não persiste sessão: o perfil do navegador é um diretório temporário
  apagado ao fechar
- ✅ só captura dentro dos domínios da lista de permissão
- ✅ o HTML devolvido é higienizado: remove `<script>`, `<iframe>`,
  `<object>`, `<embed>`, `<noscript>`, `<style>`, `<svg>`, handlers `on*`,
  valores de `value`/`checked`/`selected`, conteúdo de `<textarea>` e URLs
  `javascript:`

## API

| Método | Rota | Uso |
|---|---|---|
| GET | `/health` | servidor no ar? navegador aberto? quais domínios? |
| POST | `/open` | abre o Chromium e vai para `START_URL` |
| GET | `/status` | url, título, se o domínio é permitido |
| POST | `/goto` | navega para uma URL permitida |
| POST | `/capture` | lê a página. Body opcional: `{selector, platform}` |
| POST | `/close` | fecha o navegador e apaga o perfil temporário |

Resposta do `/capture`:

```json
{
  "ok": true,
  "url": "...",
  "title": "...",
  "capturedAt": "2026-10-20T19:00:00.000Z",
  "html": "...higienizado...",
  "text": "...texto visível...",
  "candidates": [{ "kind": "repeat", "selector": "#lista > div.task-card", "count": 5, "score": 39.4, "sample": "..." }],
  "items": [{ "title": "...", "due_date": "2026-10-25", "platform": "TarefaSP", "subject": "Matemática", "status": "pending" }],
  "selector": "#lista > div.task-card",
  "plataforma": "TarefaSP",
  "resumo": { "total": 5, "pendentes": 4, "atrasadas": 1, "concluidas": 1 }
}
```

## Se a captura vier errada

Abra **Sala do Futuro** → faça a captura → no campo **Estrutura (seletor)**
escolha outro candidato da lista (ela mostra o tipo, quantos itens achou, a
pontuação e um trecho do conteúdo) → **Recapturar**. Quando acertar, importe:
o seletor é salvo automaticamente.

Se nenhum candidato servir, use **Texto da página** para inspecionar o que
está sendo lido e me mande o JSON — dá para escrever um seletor específico em
cima do HTML real.
