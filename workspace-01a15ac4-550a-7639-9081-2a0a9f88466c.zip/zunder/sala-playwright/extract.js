'use strict';

/**
 * Extrator adaptativo.
 *
 * O HTML da Sala do Futuro / TarefaSP nao e publico e muda com o tempo.
 * Em vez de embutir seletores chutados, este modulo DESCOBRE a estrutura:
 * varre o DOM, acha os conjuntos de elementos que se repetem (que e onde
 * listas de tarefas sempre moram), pontua cada um e devolve os candidatos
 * ranqueados. O usuario escolhe o certo uma vez; o seletor fica salvo.
 *
 * Nada aqui preenche formulario, clica em botao ou envia resposta.
 * O modulo apenas LE o DOM.
 */

const PLATFORMS = [
  'TarefaSP', 'Redação Paulista', 'Redacao Paulista', 'LeiaSP+', 'Leia SP',
  'Expansão Noturna', 'Alura', 'Open English', 'Educação Profissional',
  'Matific', 'Prepara-SP', 'Khan Academy', 'Matemática EM', 'Speak', 'SPeak',
];

const SUBJECTS = [
  'Português', 'Língua Portuguesa', 'Matemática', 'História', 'Geografia',
  'Biologia', 'Física', 'Química', 'Filosofia', 'Sociologia', 'Inglês',
  'Língua Inglesa', 'Artes', 'Arte', 'Educação Física', 'Tecnologia', 'Ciências',
];

const STATUS = {
  pending: ['pendente', 'em aberto', 'a fazer', 'não entregue', 'nao entregue',
    'não enviada', 'nao enviada', 'em andamento', 'aguardando', 'aberta'],
  late: ['atrasada', 'atrasado', 'vencida', 'vencido', 'expirada', 'em atraso',
    'prazo encerrado'],
  done: ['concluída', 'concluida', 'entregue', 'enviada', 'finalizada', 'corrigida',
    'respondida', 'feita', 'realizada'],
};

const MONTHS = {
  jan: 1, fev: 2, mar: 3, abr: 4, mai: 5, jun: 6,
  jul: 7, ago: 8, set: 9, out: 10, nov: 11, dez: 12,
};

// ---------------------------------------------------------------- datas

function parseDate(text) {
  if (!text) return null;
  const t = String(text);

  // 25/10/2026 | 25-10-26 | 25.10
  let m = t.match(/(\d{1,2})[\/\-.](\d{1,2})(?:[\/\-.](\d{2,4}))?/);
  if (m) {
    let d = +m[1], mo = +m[2], y = m[3] ? +m[3] : null;
    if (mo >= 1 && mo <= 12 && d >= 1 && d <= 31) {
      if (y !== null) { if (y < 100) y += 2000; }
      else {
        const now = new Date();
        y = now.getFullYear();
        const cand = new Date(y, mo - 1, d);
        const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
        if (cand < today) y += 1;
      }
      return iso(y, mo, d);
    }
  }

  // 25 de outubro de 2026
  m = t.match(/(\d{1,2})\s+de\s+([a-zA-ZçÇ]+)(?:\s+de\s+(\d{4}))?/i);
  if (m) {
    const key = m[2].slice(0, 3).toLowerCase();
    const mo = MONTHS[key];
    if (mo) {
      const now = new Date();
      let y = m[3] ? +m[3] : now.getFullYear();
      const d = +m[1];
      if (!m[3]) {
        const cand = new Date(y, mo - 1, d);
        const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
        if (cand < today) y += 1;
      }
      return iso(y, mo, d);
    }
  }
  return null;
}

function iso(y, m, d) {
  return `${y}-${String(m).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
}

function detectStatus(text) {
  const t = String(text || '').toLowerCase();
  for (const w of STATUS.late) if (t.includes(w)) return 'late';
  for (const w of STATUS.done) if (t.includes(w)) return 'done';
  for (const w of STATUS.pending) if (t.includes(w)) return 'pending';
  return 'unknown';
}

function detectPlatform(text) {
  const t = String(text || '').toLowerCase();
  for (const p of PLATFORMS) {
    if (t.includes(p.toLowerCase())) {
      return p.replace('Redacao Paulista', 'Redação Paulista').replace('SPeak', 'Speak');
    }
  }
  return null;
}

function detectSubject(text) {
  const t = String(text || '').toLowerCase();
  for (const s of SUBJECTS) if (t.includes(s.toLowerCase())) return s;
  return null;
}

// ------------------------------------------------- descoberta (no browser)

/**
 * Roda DENTRO da pagina. Nao pode usar closure: e serializada por toString().
 */
function detectInPage() {
  const STOP = new Set(['SCRIPT', 'STYLE', 'NOSCRIPT', 'SVG', 'PATH', 'BR', 'HR']);

  function clsOf(el) {
    const c = el.getAttribute && el.getAttribute('class');
    if (!c) return '';
    return String(c).trim().split(/\s+/).filter(Boolean).slice(0, 3).join('.');
  }

  function childKey(el) {
    return el.tagName.toLowerCase() + (clsOf(el) ? '.' + clsOf(el) : '');
  }

  function selectorFor(el) {
    if (!el || el === document.body) return 'body';
    const parts = [];
    let cur = el;
    let depth = 0;
    while (cur && cur !== document.documentElement && depth < 5) {
      const id = cur.getAttribute && cur.getAttribute('id');
      if (id && !/^\d/.test(id) && document.querySelectorAll('#' + CSS.escape(id)).length === 1) {
        parts.unshift('#' + CSS.escape(id));
        return parts.join(' > ');
      }
      parts.unshift(childKey(cur));
      cur = cur.parentElement;
      depth++;
    }
    return parts.join(' > ');
  }

  function txt(el) {
    return (el.innerText || el.textContent || '').replace(/\s+/g, ' ').trim();
  }

  function scoreOf(texts, depth, count) {
    let s = 0;
    s += Math.min(count, 25);                       // listas maiores sao melhor pista
    const avg = texts.reduce((a, t) => a + t.length, 0) / Math.max(1, texts.length);
    if (avg >= 15 && avg <= 400) s += 12;
    if (avg > 800) s -= 10;                          // bloco inteiro, nao item
    let hits = { date: 0, status: 0, plat: 0 };
    for (const t of texts) {
      const low = t.toLowerCase();
      if (/\d{1,2}\s*[\/\-.]\s*\d{1,2}/.test(t) || /\d{1,2}\s+de\s+[a-zç]+/i.test(t)) hits.date++;
      if (/(pendente|atrasad|conclu|entregue|enviada|em aberto|vencid|n.o (entregue|enviada))/i.test(low)) hits.status++;
      if (/(tarefa\s?sp|reda..o paulista|leia\s?sp|matific|khan|alura|spe?speak|matem.tica em)/i.test(low)) hits.plat++;
    }
    const n = Math.max(1, texts.length);
    s += (hits.date / n) * 14;
    s += (hits.status / n) * 10;
    s += (hits.plat / n) * 8;
    s -= depth * 0.4;
    if (count > 300) s -= 8;
    return Math.round(s * 10) / 10;
  }

  const out = [];
  const seen = new Set();
  const all = Array.from(document.querySelectorAll('body *'));

  // 1) tabelas
  for (const tb of Array.from(document.querySelectorAll('table'))) {
    const rows = Array.from(tb.querySelectorAll('tr'));
    if (rows.length >= 2) {
      const texts = rows.map(txt).filter(Boolean);
      const sel = selectorFor(tb) + ' tr';
      if (!seen.has(sel)) {
        seen.add(sel);
        out.push({
          kind: 'table', selector: sel, count: rows.length,
          sample: texts.slice(0, 3).join(' | ').slice(0, 300),
          score: scoreOf(texts, 3, rows.length) + 6,
          headers: Array.from(tb.querySelectorAll('th')).map(txt).slice(0, 10),
        });
      }
    }
  }

  // 2) grupos de irmaos repetidos (cards, <li>, divs de lista)
  const parents = new Set(all.map((el) => el.parentElement).filter(Boolean));
  for (const parent of parents) {
    const kids = Array.from(parent.children);
    if (kids.length < 2 || kids.length > 400) continue;

    const buckets = new Map();
    for (const k of kids) {
      if (STOP.has(k.tagName)) continue;
      const key = childKey(k);
      if (!buckets.has(key)) buckets.set(key, []);
      buckets.get(key).push(k);
    }

    for (const [key, group] of buckets) {
      if (group.length < 2) continue;
      const texts = group.map(txt).filter((t) => t.length > 0);
      if (texts.length < 2) continue;

      const pSel = selectorFor(parent);
      const sel = pSel + ' > ' + key.split('.')[0] +
        (key.includes('.') ? '.' + key.split('.').slice(1).join('.') : '');
      if (seen.has(sel)) continue;
      seen.add(sel);

      let depth = 0, cur = parent;
      while (cur) { depth++; cur = cur.parentElement; }

      out.push({
        kind: group[0].tagName === 'LI' ? 'list' : 'repeat',
        selector: sel,
        count: group.length,
        sample: texts.slice(0, 3).join(' | ').slice(0, 300),
        score: scoreOf(texts, depth, group.length),
      });
    }
  }

  // 3) JSON embutido (Next.js / Nuxt / estado inicial)
  const embedded = [];
  const tryScript = (el, label) => {
    if (!el) return;
    let raw = el.textContent || '';
    raw = raw.trim();
    if (!raw || raw.length > 3_000_000) return;
    let parsed = null;
    try { parsed = JSON.parse(raw); } catch (_) { return; }
    embedded.push({ label, keys: Object.keys(parsed).slice(0, 25), size: raw.length });
  };
  tryScript(document.getElementById('__NEXT_DATA__'), '__NEXT_DATA__');
  Array.from(document.querySelectorAll('script[type="application/ld+json"]'))
    .forEach((el, i) => tryScript(el, 'ld+json[' + i + ']'));

  out.sort((a, b) => b.score - a.score);
  return { candidates: out.slice(0, 12), embedded };
}

// ------------------------------------------------------- coleta (no Node)

// Rótulos de campo que aparecem colados ao título e devem sair.
const LABELS = /\b(entrega|entregar|prazo|vencimento|data de entrega|data|status|situação|situacao|matéria|materia|disciplina|turma|professor|nota|devolutiva)\s*:?\s*/gi;

// Restos de palavra que sobram no fim depois de remover data/rótulo.
const TAIL = /[\s\-–—|:,.]*$/;

function parseItem(text, opts) {
  const options = opts || {};
  const clean = String(text || '').replace(/\s+/g, ' ').trim();
  if (!clean) return null;

  const due = parseDate(clean);
  const platform = detectPlatform(clean) || options.defaultPlatform || null;
  const subject = detectSubject(clean);

  let title = clean;

  // corta no marcador de status, se nao for no comeco
  const cut = title.search(/(pendente|atrasad|conclu|entregue|enviada|em aberto|vencid)/i);
  if (cut > 12) title = title.slice(0, cut);

  // remove a data
  if (due) {
    title = title.replace(
      /(\d{1,2}\s*[\/\-.]\s*\d{1,2}(?:\s*[\/\-.]\s*\d{2,4})?|\d{1,2}\s+de\s+[a-zA-ZçÇ]+(?:\s+de\s+\d{4})?)/i,
      ' '
    );
  }

  // remove rótulos de campo
  title = title.replace(LABELS, ' ');

  // remove a materia do titulo, se ela aparecer isolada
  if (subject) {
    title = title.replace(new RegExp('^' + subject.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '\\s*[-–—:|]?\\s*', 'i'), '');
  }

  // numeração e marcadores no início
  title = title.replace(/^[\d]+[.).]?\s*/, '').replace(/^[-•*·]\s*/, '');

  // limpa sobras no fim ('Entre', 'Entrega', 'at', etc.)
  title = title.replace(TAIL, '');
  for (let i = 0; i < 3; i++) {
    const before = title;
    title = title.replace(/\s+\S{1,8}$/, (m) => {
      const w = m.trim().toLowerCase();
      const junk = ['entrega', 'entre', 'at', 'ate', 'até', 'em', 'de', 'do', 'da', 'para', 'e', 'ou', 'a', 'o', 'em', 'por', '-', '–', '—'];
      return junk.includes(w) ? '' : m;
    });
    title = title.replace(TAIL, '');
    if (title === before) break;
  }

  title = title.replace(/\s{2,}/g, ' ').trim();
  if (!title || title.length < 3) title = clean.slice(0, 90);

  return {
    title: title.slice(0, 180),
    due_date: due,
    platform: platform,
    subject: subject || 'Outro',
    status: detectStatus(clean),
    raw: clean.slice(0, 400),
  };
}

/**
 * Roda no Node: aplica o seletor escolhido (ou o melhor candidato),
 * extrai os textos e transforma em itens estruturados.
 */
async function collect(page, opts) {
  const chosen = opts && opts.selector ? String(opts.selector) : null;

  const detected = await page.evaluate(detectInPage);

  let selector = chosen;
  let kind = 'manual';
  if (!selector) {
    if (!detected.candidates.length) {
      return { candidates: [], embedded: detected.embedded, items: [], selector: null, kind: null };
    }
    selector = detected.candidates[0].selector;
    kind = detected.candidates[0].kind;
  } else {
    const known = detected.candidates.find((c) => c.selector === selector);
    kind = known ? known.kind : 'manual';
  }

  let texts = [];
  try {
    texts = await page.$$eval(selector, (els) =>
      els.map((el) => (el.innerText || el.textContent || '').replace(/\s+/g, ' ').trim())
    );
  } catch (_) {
    return { candidates: detected.candidates, embedded: detected.embedded, items: [], selector, kind, error: 'seletor invalido' };
  }

  const items = texts
    .map((t) => parseItem(t, { defaultPlatform: (opts && opts.defaultPlatform) || null }))
    .filter(Boolean)
    .filter((it) => it.title.length >= 3);

  // remove duplicatas por titulo+prazo
  const seen = new Set();
  const uniq = [];
  for (const it of items) {
    const k = it.title.toLowerCase() + '|' + (it.due_date || '');
    if (seen.has(k)) continue;
    seen.add(k);
    uniq.push(it);
  }

  return {
    candidates: detected.candidates,
    embedded: detected.embedded,
    items: uniq,
    selector,
    kind,
  };
}

/** Tenta descobrir a plataforma pelo titulo/URL/texto da pagina. */
async function inferPlatform(page) {
  let blob = '';
  try {
    blob = await page.evaluate(() => {
      const h = Array.from(document.querySelectorAll('h1,h2')).slice(0, 3)
        .map((e) => (e.innerText || '')).join(' ');
      return (document.title || '') + ' ' + h + ' ' + location.href;
    });
  } catch (_) {}
  return detectPlatform(blob);
}

module.exports = { collect, parseItem, parseDate, detectStatus, detectPlatform, detectSubject, inferPlatform };
